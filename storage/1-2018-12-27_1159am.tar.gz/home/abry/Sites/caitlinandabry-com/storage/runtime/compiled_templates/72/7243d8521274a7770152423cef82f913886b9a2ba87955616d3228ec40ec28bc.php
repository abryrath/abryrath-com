<?php

/* photos/_entry */
class __TwigTemplate_db0c4d224efbadd8afc76dd2c4c6e10c710e79e6e7661c0a749024d4a866e6c8 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/default", "photos/_entry", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/default";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo "    ";
        $cacheService = Craft::$app->getTemplateCaches();
        $request = Craft::$app->getRequest();
        $ignoreCache1 = ($request->getIsLivePreview() || $request->getToken() || ((getenv("APP_ENV") == "development")));
        if (!$ignoreCache1) {
            $cacheKey1 = "rzixsuV8ITGxOgdpKA0FoDcAqZIfq8ij0fxt";
            $cacheBody1 = $cacheService->getTemplateCache($cacheKey1, true);
        } else {
            $cacheBody1 = null;
        }
        if ($cacheBody1 === null) {
            if (!$ignoreCache1) {
                $cacheService->startTemplateCache($cacheKey1);
            }
            ob_start();
            // line 4
            echo "    ";
            $context["hero"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "pageHeroImage", array());
            // line 5
            echo "    ";
            if (twig_length_filter($this->env, ($context["hero"] ?? null))) {
                // line 6
                echo "        <div class=\"Hero\">
            <img src=\"";
                // line 7
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["hero"] ?? null), "one", array()), "getUrl", array()), "html", null, true);
                echo "\"/>
        </div>
    ";
            }
            // line 10
            echo "
    ";
            // line 11
            $this->loadTemplate("_partials/wysiwyg", "photos/_entry", 11)->display(array("content" => array("sectionHeading" => "Photos", "copy" => "")));
            // line 18
            echo "
    <div class=\"Photos\" data-photos=\" ";
            // line 19
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter($this->extensions['abryrath\wedding\twigextensions\AppTwigExtension']->photosSrc(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "photos", array()), "all", array()))), "html", null, true);
            echo "\">
        ";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->extensions['abryrath\wedding\twigextensions\AppTwigExtension']->photosSrc(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "photos", array()), "all", array())));
            foreach ($context['_seq'] as $context["i"] => $context["photo"]) {
                // line 21
                echo "            <div class=\"Photos-card\" data-photo-src=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["photo"], "src", array()), "html", null, true);
                echo "\" data-photo-index=\"";
                echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                echo "\">
                <div class=\"Image\">
                    <img src=\"";
                // line 23
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["photo"], "preview", array()), "html", null, true);
                echo "\">
                </div>
            </div>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['i'], $context['photo'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 27
            echo "    </div>
    <div class=\"Photos-modal\" data-current=\"{}\">
        <div class=\"Photos-modal--content\">
            <div class=\"Photos-modal--arrows left\" data-prev=\"1\">
                <i class=\"fa fa-chevron-left\"></i>
            </div>
            <div class=\"Photos-modal--arrows right\" data-next=\"1\">
                <i class=\"fa fa-chevron-right\"></i>
            </div>
            <div class=\"Photos-modal--info bottom\" data-info=\"1\"></div>
            <div class=\"Photos-modal--arrows top right\" data-close=\"1\">
                <i class=\"fa fa-times-circle\"></i>
            </div>
            <div class=\"Image\">
                <img data-photo-window=\"1\" src=\"\">
            </div>
        </div>
    </div>
    ";
            $cacheBody1 = ob_get_clean();
            if (!$ignoreCache1) {
                $cacheService->endTemplateCache($cacheKey1, true, null, null, $cacheBody1);
            }
        }
        echo $cacheBody1;
    }

    public function getTemplateName()
    {
        return "photos/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  100 => 27,  90 => 23,  82 => 21,  78 => 20,  74 => 19,  71 => 18,  69 => 11,  66 => 10,  60 => 7,  57 => 6,  54 => 5,  51 => 4,  35 => 3,  32 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "photos/_entry", "/home/abry/Sites/caitlinandabry-com/templates/photos/_entry.twig");
    }
}
