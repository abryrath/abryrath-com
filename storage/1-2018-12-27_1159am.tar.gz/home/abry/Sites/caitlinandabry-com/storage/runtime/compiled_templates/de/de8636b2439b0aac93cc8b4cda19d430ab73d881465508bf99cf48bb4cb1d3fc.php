<?php

/* things-to-do/dine/index */
class __TwigTemplate_b95dbedf39e338c194dd76a6c49375c78b8835e5387288163df74e9a1a1a298f extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 2
        return $this->loadTemplate(((($context["isAjax"] ?? null)) ? ("_layouts/ajax") : ("_layouts/default")), "things-to-do/dine/index", 2);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["isAjax"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "isAjax", array());
        // line 4
        $context["costFilter"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "getParam", array(0 => "cost"), "method");
        // line 5
        $context["cuisineFilter"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "getParam", array(0 => "cuisine"), "method");
        // line 6
        $context["areasFilter"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "getParam", array(0 => "areas"), "method");
        // line 7
        $context["restaurantQuery"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "get", array(0 => "restaurants"), "method"), "filter", array(0 => array("cost" =>         // line 8
($context["costFilter"] ?? null), "cuisine" =>         // line 9
($context["cuisineFilter"] ?? null), "areas" =>         // line 10
($context["areasFilter"] ?? null), "orderBy" => "title asc")), "method");
        // line 14
        $context["cuisines"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "entries", array()), "section", array(0 => "cuisines"), "method"), "all", array());
        // line 15
        $context["costs"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "entries", array()), "section", array(0 => "costs"), "method"), "orderBy", array(0 => "title desc"), "method"), "all", array());
        // line 16
        $context["areas"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "entries", array()), "section", array(0 => "areas"), "method"), "orderBy", array(0 => "title asc"), "method"), "all", array());
        // line 2
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 18
    public function block_content($context, array $blocks = array())
    {
        // line 19
        echo "    ";
        if (($context["isAjax"] ?? null)) {
            // line 20
            echo "        ";
            $context["showPlaces"] = array();
            // line 21
            echo "        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["restaurantQuery"] ?? null), "all", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["place"]) {
                // line 22
                echo "            ";
                if ( !twig_test_empty(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["place"], "location", array()))) {
                    // line 23
                    echo "                ";
                    $context["showPlaces"] = twig_array_merge(($context["showPlaces"] ?? null), array(0 => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["place"], "location", array())));
                    // line 24
                    echo "            ";
                }
                // line 25
                echo "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['place'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 26
            echo "        ";
            echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(($context["showPlaces"] ?? null));
            echo "
    ";
        } else {
            // line 28
            echo "        ";
            $this->loadTemplate("_partials/wysiwyg", "things-to-do/dine/index", 28)->display(array("content" => array("sectionHeading" => "Dine", "copy" => "")));
            // line 34
            echo "        
        ";
            // line 35
            $this->loadTemplate("things-to-do/listingFilter", "things-to-do/dine/index", 35)->display(array("type" => "things-to-do/dine", "cuisines" =>             // line 37
($context["cuisines"] ?? null), "costs" =>             // line 38
($context["costs"] ?? null), "areas" =>             // line 39
($context["areas"] ?? null)));
            // line 41
            echo "
        ";
            // line 42
            $this->loadTemplate("_partials/map", "things-to-do/dine/index", 42)->display(array("places" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 43
($context["restaurantQuery"] ?? null), "all", array(), "method")));
            // line 45
            echo "    ";
        }
    }

    public function getTemplateName()
    {
        return "things-to-do/dine/index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 45,  101 => 43,  100 => 42,  97 => 41,  95 => 39,  94 => 38,  93 => 37,  92 => 35,  89 => 34,  86 => 28,  80 => 26,  74 => 25,  71 => 24,  68 => 23,  65 => 22,  60 => 21,  57 => 20,  54 => 19,  51 => 18,  47 => 2,  45 => 16,  43 => 15,  41 => 14,  39 => 10,  38 => 9,  37 => 8,  36 => 7,  34 => 6,  32 => 5,  30 => 4,  28 => 1,  22 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "things-to-do/dine/index", "/home/abry/Sites/caitlinandabry-com/templates/things-to-do/dine/index.twig");
    }
}
