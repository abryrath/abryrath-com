<?php

/* registry/_entry */
class __TwigTemplate_6a80140058b540ba97097eda6d03473920a661023eda2b0baf196ac1e77fd43f extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/default", "registry/_entry", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/default";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo "    ";
        $cacheService = Craft::$app->getTemplateCaches();
        $request = Craft::$app->getRequest();
        $ignoreCache1 = ($request->getIsLivePreview() || $request->getToken() || ((getenv("APP_ENV") == "development")));
        if (!$ignoreCache1) {
            $cacheKey1 = "UwIQAmQ3a2wZICVb6Bh9XQ4q3p9RSyAMH89c";
            $cacheBody1 = $cacheService->getTemplateCache($cacheKey1, true);
        } else {
            $cacheBody1 = null;
        }
        if ($cacheBody1 === null) {
            if (!$ignoreCache1) {
                $cacheService->startTemplateCache($cacheKey1);
            }
            ob_start();
            // line 4
            echo "        ";
            $context["hero"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "pageHeroImage", array());
            // line 5
            echo "        ";
            if (twig_length_filter($this->env, ($context["hero"] ?? null))) {
                // line 6
                echo "            <div class=\"Hero\">
                <img src=\"";
                // line 7
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["hero"] ?? null), "one", array()), "getUrl", array()), "html", null, true);
                echo "\"/>
            </div>
        ";
            }
            // line 10
            echo "
        ";
            // line 11
            $this->loadTemplate("_partials/wysiwyg", "registry/_entry", 11)->display(array("content" => array("sectionHeading" => "Registry", "copy" => "")));
            // line 17
            echo "
        <div class=\"Registry\">
            ";
            // line 19
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "links", array()), "all", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
                // line 20
                echo "                ";
                $this->loadTemplate("registry/card", "registry/_entry", 20)->display(array("content" =>                 // line 21
$context["link"]));
                // line 23
                echo "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['link'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 24
            echo "        </div>
    ";
            $cacheBody1 = ob_get_clean();
            if (!$ignoreCache1) {
                $cacheService->endTemplateCache($cacheKey1, true, null, null, $cacheBody1);
            }
        }
        echo $cacheBody1;
    }

    public function getTemplateName()
    {
        return "registry/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 24,  83 => 23,  81 => 21,  79 => 20,  75 => 19,  71 => 17,  69 => 11,  66 => 10,  60 => 7,  57 => 6,  54 => 5,  51 => 4,  35 => 3,  32 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "registry/_entry", "/home/abry/Sites/caitlinandabry-com/templates/registry/_entry.twig");
    }
}
