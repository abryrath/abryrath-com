<?php

/* things-to-do/listingFilter */
class __TwigTemplate_e0721cf9aa415d4d281b9991f7e205b2335fd4b1fe9512f790f4f68b605b0467 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"Controls\" data-filter-data-type=\"";
        echo twig_escape_filter($this->env, ($context["type"] ?? null), "html", null, true);
        echo "\">
    ";
        // line 2
        if ((isset($context["cuisines"]) || array_key_exists("cuisines", $context))) {
            // line 3
            echo "        <select class=\"Controls-dropdown\" data-filter=\"cuisine\">
            <option default value=\"\">Cuisine</option>
            ";
            // line 5
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["cuisines"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["cuisine"]) {
                // line 6
                echo "                <option value=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["cuisine"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["cuisine"], "title", array()), "html", null, true);
                echo "</option>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cuisine'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 8
            echo "        </select>
    ";
        }
        // line 10
        echo "    
    ";
        // line 11
        if ((isset($context["costs"]) || array_key_exists("costs", $context))) {
            // line 12
            echo "        <select class=\"Controls-dropdown\" data-filter=\"cost\">
            <option default value=\"\">Cost</option>
            ";
            // line 14
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["costs"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["cost"]) {
                // line 15
                echo "                <option value=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["cost"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["cost"], "title", array()), "html", null, true);
                echo "</option>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cost'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 17
            echo "        </select>
    ";
        }
        // line 19
        echo "
    ";
        // line 20
        if ((isset($context["areas"]) || array_key_exists("areas", $context))) {
            // line 21
            echo "        <select class=\"Controls-dropdown\" data-filter=\"areas\">
            <option default value=\"\">Areas</option>
            ";
            // line 23
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["areas"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["area"]) {
                // line 24
                echo "                <option value=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["area"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["area"], "title", array()), "html", null, true);
                echo "</option>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['area'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 26
            echo "        </select>
    ";
        }
        // line 28
        echo "
    ";
        // line 29
        if (((isset($context["epicentre"]) || array_key_exists("epicentre", $context)) && ($context["epicentre"] ?? null))) {
            // line 30
            echo "        <div class=\"Controls-checkbox-group\" data-filter=\"epicentre\">
            <label for=\"checkbox-epicentre\"></label>
            <input type=\"checkbox\" id=\"checkbox-epicentre\" class=\"Controls-checkbox\" data-label=\"Epicentre\" checked=true>
            <label for=\"checkbox-other\"></label>
            <input type=\"checkbox\" id=\"checkbox-other\" class=\"Controls-checkbox\" data-label=\"Other\" checked=true>
        </div>
    ";
        }
        // line 37
        echo "</div>";
    }

    public function getTemplateName()
    {
        return "things-to-do/listingFilter";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  123 => 37,  114 => 30,  112 => 29,  109 => 28,  105 => 26,  94 => 24,  90 => 23,  86 => 21,  84 => 20,  81 => 19,  77 => 17,  66 => 15,  62 => 14,  58 => 12,  56 => 11,  53 => 10,  49 => 8,  38 => 6,  34 => 5,  30 => 3,  28 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "things-to-do/listingFilter", "/home/abry/Sites/caitlinandabry-com/templates/things-to-do/listingFilter.twig");
    }
}
