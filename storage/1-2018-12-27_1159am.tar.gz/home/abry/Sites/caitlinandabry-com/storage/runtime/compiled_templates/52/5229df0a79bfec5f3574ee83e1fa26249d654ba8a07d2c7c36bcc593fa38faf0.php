<?php

/* wedding-party/person */
class __TwigTemplate_6909ec55644b9a1a7115811e6ed386f58bf2fc9003edaea6724a0e6ad67aafc5 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"WeddingParty-card\">
    <div class=\"Image\">
        <img src=\"";
        // line 3
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["member"] ?? null), "weddingPartyMemberPicture", array()), "one", array()), "getUrl", array(0 => "headshot"), "method"), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["member"] ?? null), "weddingPartyMemberName", array()), "html", null, true);
        echo "\">
    </div>
    <div class=\"WeddingParty-card--name\">";
        // line 5
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["member"] ?? null), "weddingPartyMemberName", array()), "html", null, true);
        echo "</div>
    <div class=\"WeddingParty-card--position\">";
        // line 6
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["member"] ?? null), "weddingPartyMemberPosition", array()), "html", null, true);
        echo "</div>
    <div class=\"WeddingParty-card--relation\">";
        // line 7
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["member"] ?? null), "weddingPartyMemberRelation", array()), "html", null, true);
        echo "</div>
</div>
";
    }

    public function getTemplateName()
    {
        return "wedding-party/person";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  42 => 7,  38 => 6,  34 => 5,  27 => 3,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "wedding-party/person", "/home/abry/Sites/caitlinandabry-com/templates/wedding-party/person.twig");
    }
}
