<?php

/* _includes/forms/field */
class __TwigTemplate_05a3783878c6a7e5a97e6e27edb2a54b99145fb624086a84f082dc898e158007 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["labelId"] = (((isset($context["labelId"]) || array_key_exists("labelId", $context))) ? (($context["labelId"] ?? null)) : ((((isset($context["id"]) || array_key_exists("id", $context))) ? ((($context["id"] ?? null) . "-label")) : (null))));
        // line 2
        $context["fieldId"] = (((isset($context["fieldId"]) || array_key_exists("fieldId", $context))) ? (($context["fieldId"] ?? null)) : ((((isset($context["id"]) || array_key_exists("id", $context))) ? ((($context["id"] ?? null) . "-field")) : (null))));
        // line 3
        $context["label"] = ((((isset($context["label"]) || array_key_exists("label", $context)) && (($context["label"] ?? null) != "__blank__"))) ? (($context["label"] ?? null)) : (null));
        // line 4
        $context["siteId"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "getIsMultiSite", array(), "method") && (isset($context["siteId"]) || array_key_exists("siteId", $context)))) ? (($context["siteId"] ?? null)) : (null));
        // line 5
        $context["site"] = ((($context["siteId"] ?? null)) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "sites", array()), "getSiteById", array(0 => ($context["siteId"] ?? null)), "method")) : (null));
        // line 6
        $context["instructions"] = (((isset($context["instructions"]) || array_key_exists("instructions", $context))) ? (($context["instructions"] ?? null)) : (null));
        // line 7
        $context["warning"] = (((isset($context["warning"]) || array_key_exists("warning", $context))) ? (($context["warning"] ?? null)) : (null));
        // line 8
        $context["orientation"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ((($context["site"] ?? null)) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "i18n", array()), "getLocaleById", array(0 => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["site"] ?? null), "language", array())), "method")) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "locale", array()))), "getOrientation", array(), "method");
        // line 9
        $context["translatable"] = (($context["translatable"]) ?? ( !(($context["site"] ?? null) === null)));
        // line 10
        $context["errors"] = (((isset($context["errors"]) || array_key_exists("errors", $context))) ? (($context["errors"] ?? null)) : (null));
        // line 11
        $context["fieldClass"] = twig_join_filter(array_filter(array(0 => "field", 1 => (((        // line 13
(isset($context["first"]) || array_key_exists("first", $context)) && ($context["first"] ?? null))) ? ("first") : (null)), 2 => ((        // line 14
($context["errors"] ?? null)) ? ("has-errors") : (null)), 3 => (((        // line 15
(isset($context["fieldClass"]) || array_key_exists("fieldClass", $context)) && ($context["fieldClass"] ?? null))) ? (($context["fieldClass"] ?? null)) : (null)))), " ");
        // line 17
        echo "
<div class=\"";
        // line 18
        echo twig_escape_filter($this->env, ($context["fieldClass"] ?? null), "html", null, true);
        echo "\"";
        // line 19
        if (($context["fieldId"] ?? null)) {
            echo " id=\"";
            echo twig_escape_filter($this->env, ($context["fieldId"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 20
        if (        $this->hasBlock("attr", $context, $blocks)) {
            echo " ";
            $this->displayBlock("attr", $context, $blocks);
        }
        echo ">
    ";
        // line 21
        if ((($context["label"] ?? null) || ($context["instructions"] ?? null))) {
            // line 22
            echo "        <div class=\"heading\">
            ";
            // line 23
            if (($context["label"] ?? null)) {
                // line 24
                echo "                <label ";
                if (($context["labelId"] ?? null)) {
                    echo " id=\"";
                    echo twig_escape_filter($this->env, ($context["labelId"] ?? null), "html", null, true);
                    echo "\"";
                }
                if (((isset($context["required"]) || array_key_exists("required", $context)) && ($context["required"] ?? null))) {
                    echo " class=\"required\"";
                }
                if (((isset($context["id"]) || array_key_exists("id", $context)) && ($context["id"] ?? null))) {
                    echo " for=\"";
                    echo twig_escape_filter($this->env, ($context["id"] ?? null), "html", null, true);
                    echo "\"";
                }
                echo ">";
                // line 25
                echo ($context["label"] ?? null);
                // line 26
                if (($context["translatable"] ?? null)) {
                    echo " <span class=\"extralight\" data-icon=\"language\" title=\"";
                    echo twig_escape_filter($this->env, (($context["translationDescription"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("This field is translatable.", "app"))), "html", null, true);
                    echo "\"></span>";
                }
                // line 27
                echo "</label>
            ";
            }
            // line 29
            echo "            ";
            if (($context["instructions"] ?? null)) {
                // line 30
                echo "                <div class=\"instructions\">";
                echo $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->markdownFilter(($context["instructions"] ?? null)), "/&amp;(\\w+);/", "&\$1;");
                echo "</div>
            ";
            }
            // line 32
            echo "        </div>
    ";
        }
        // line 34
        echo "    <div class=\"input ";
        echo twig_escape_filter($this->env, ($context["orientation"] ?? null), "html", null, true);
        if (($context["errors"] ?? null)) {
            echo " errors";
        }
        echo "\">
        ";
        // line 35
        echo ($context["input"] ?? null);
        echo "
    </div>
    ";
        // line 37
        if (($context["warning"] ?? null)) {
            // line 38
            echo "        <p class=\"warning\">";
            echo $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->markdownFilter(($context["warning"] ?? null), null, true), "/&amp;(\\w+);/", "&\$1;");
            echo "</p>
    ";
        }
        // line 40
        echo "    ";
        $this->loadTemplate("_includes/forms/errorList", "_includes/forms/field", 40)->display(array_merge($context, array("errors" => ($context["errors"] ?? null))));
        // line 41
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "_includes/forms/field";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 41,  136 => 40,  130 => 38,  128 => 37,  123 => 35,  115 => 34,  111 => 32,  105 => 30,  102 => 29,  98 => 27,  92 => 26,  90 => 25,  74 => 24,  72 => 23,  69 => 22,  67 => 21,  60 => 20,  54 => 19,  51 => 18,  48 => 17,  46 => 15,  45 => 14,  44 => 13,  43 => 11,  41 => 10,  39 => 9,  37 => 8,  35 => 7,  33 => 6,  31 => 5,  29 => 4,  27 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_includes/forms/field", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/_includes/forms/field.html");
    }
}
