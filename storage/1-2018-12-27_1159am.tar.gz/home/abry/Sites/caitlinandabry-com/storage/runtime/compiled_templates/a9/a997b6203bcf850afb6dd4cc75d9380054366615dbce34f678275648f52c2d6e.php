<?php

/* 404 */
class __TwigTemplate_6914a927047d9bce60c94faa66d309b109c63ad2e0ec65089d24d01996d13546 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/message", "404", 1);
        $this->blocks = array(
            'message' => array($this, 'block_message'),
            '__internal_bdefe1ecf0e67153e9650c3b9f88940f17a9e3c2829645933218faff6d19ba39' => array($this, 'block___internal_bdefe1ecf0e67153e9650c3b9f88940f17a9e3c2829645933218faff6d19ba39'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/message";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Page Not Found", "app");
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_message($context, array $blocks = array())
    {
        // line 5
        echo "    <h2>";
        echo twig_escape_filter($this->env, ($context["title"] ?? null), "html", null, true);
        echo "</h2>

    ";
        // line 7
        if (($context["message"] ?? null)) {
            // line 8
            echo "        ";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->markdownFilter(            $this->renderBlock("__internal_bdefe1ecf0e67153e9650c3b9f88940f17a9e3c2829645933218faff6d19ba39", $context, $blocks)), "html", null, true);
            // line 9
            echo "    ";
        } else {
            // line 10
            echo "        <p>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("The requested URL was not found on this server.", "app"), "html", null, true);
            echo "</p>
    ";
        }
    }

    // line 8
    public function block___internal_bdefe1ecf0e67153e9650c3b9f88940f17a9e3c2829645933218faff6d19ba39($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, ($context["message"] ?? null), "html", null, true);
    }

    public function getTemplateName()
    {
        return "404";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 8,  53 => 10,  50 => 9,  47 => 8,  45 => 7,  39 => 5,  36 => 4,  32 => 1,  30 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "404", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/404.html");
    }
}
