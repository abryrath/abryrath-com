<?php

/* _components/widgets/CraftSupport/body */
class __TwigTemplate_9d0430dfb8c815d384e74c1c770a4c5cbc0841ac57f971f7855dcd3ee478f6ab extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 77
        echo "
";
        // line 78
        $context["__internal_b2c7104716913b065ca0b88bd717bd092d0c34c2436e1fb5c5ce7c382b31dd29"] = $this;
        // line 79
        echo "

<div class=\"cs-screen cs-screen-home\">
    <div class=\"cs-opt\" data-screen=\"help\">
        <div class=\"cs-opt-icon\">";
        // line 83
        echo ($context["buoeyIcon"] ?? null);
        echo "</div>
        <h2>";
        // line 84
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Get help", "app"), "html", null, true);
        echo "</h2>
        <p>";
        // line 85
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("How-to’s and other questions", "app"), "html", null, true);
        echo "</p>
    </div>
    <div class=\"cs-opt\" data-screen=\"feedback\">
        <div class=\"cs-opt-icon\">";
        // line 88
        echo ($context["bullhornIcon"] ?? null);
        echo "</div>
        <h2>";
        // line 89
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Give feedback", "app"), "html", null, true);
        echo "</h2>
        <p>";
        // line 90
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Bug reports and feature requests", "app"), "html", null, true);
        echo "</p>
    </div>
</div>

";
        // line 94
        echo $context["__internal_b2c7104716913b065ca0b88bd717bd092d0c34c2436e1fb5c5ce7c382b31dd29"]->macro_screen(($context["widget"] ?? null), ($context["showBackupOption"] ?? null), "help", $this->extensions['craft\web\twig\Extension']->translateFilter("Briefly describe your question.", "app"), ($context["seIcon"] ?? null), $this->extensions['craft\web\twig\Extension']->translateFilter("Similar questions on Stack Exchange", "app"), "https://craftcms.stackexchange.com/questions/ask", $this->extensions['craft\web\twig\Extension']->translateFilter("Ask on Stack Exchange", "app"));
        echo "

";
        // line 96
        echo $context["__internal_b2c7104716913b065ca0b88bd717bd092d0c34c2436e1fb5c5ce7c382b31dd29"]->macro_screen(($context["widget"] ?? null), ($context["showBackupOption"] ?? null), "feedback", $this->extensions['craft\web\twig\Extension']->translateFilter("Briefly describe your issue or idea.", "app"), ($context["ghIcon"] ?? null), $this->extensions['craft\web\twig\Extension']->translateFilter("Similar issues on GitHub", "app"), "https://github.com/craftcms/cms/issues/new", $this->extensions['craft\web\twig\Extension']->translateFilter("Post on GitHub", "app"));
        echo "
";
    }

    // line 1
    public function macro_screen($__widget__ = null, $__showBackupOption__ = null, $__screen__ = null, $__placeholder__ = null, $__resultsIcon__ = null, $__resultsHeading__ = null, $__formAction__ = null, $__submitText__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "widget" => $__widget__,
            "showBackupOption" => $__showBackupOption__,
            "screen" => $__screen__,
            "placeholder" => $__placeholder__,
            "resultsIcon" => $__resultsIcon__,
            "resultsHeading" => $__resultsHeading__,
            "formAction" => $__formAction__,
            "submitText" => $__submitText__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 2
            echo "    ";
            $context["forms"] = $this->loadTemplate("_includes/forms", "_components/widgets/CraftSupport/body", 2);
            // line 3
            echo "    ";
            $context["idPrefix"] = (("cs-" . ($context["screen"] ?? null)) . twig_random($this->env));
            // line 4
            echo "
    <div class=\"cs-screen cs-screen-2 cs-screen-";
            // line 5
            echo twig_escape_filter($this->env, ($context["screen"] ?? null), "html", null, true);
            echo "\" action=\"";
            echo twig_escape_filter($this->env, ($context["formAction"] ?? null), "html", null, true);
            echo "\" method=\"get\" target=\"_blank\">
        ";
            // line 6
            echo $context["forms"]->macro_textareaField(array("first" => true, "class" => "cs-body-text", "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter(            // line 9
($context["placeholder"] ?? null), "app"), "rows" => 5));
            // line 11
            echo "
        <div class=\"cs-search-results-container hidden\">
            <div class=\"cs-search-icon\">";
            // line 13
            echo ($context["resultsIcon"] ?? null);
            echo "</div>
            <h2>";
            // line 14
            echo twig_escape_filter($this->env, ($context["resultsHeading"] ?? null), "html", null, true);
            echo "</h2>
            <ul class=\"cs-search-results\"></ul>
        </div>
        <div class=\"cs-forms\">
            <form class=\"cs-search-form\" action=\"";
            // line 18
            echo twig_escape_filter($this->env, ($context["formAction"] ?? null), "html", null, true);
            echo "\" method=\"get\" target=\"_blank\">
                <div class=\"cs-search-params\"></div>
                <input type=\"submit\" class=\"btn submit fullwidth disabled\" value=\"";
            // line 20
            echo twig_escape_filter($this->env, ($context["submitText"] ?? null), "html", null, true);
            echo "\">
                <p>";
            // line 21
            echo $this->extensions['craft\web\twig\Extension']->translateFilter("or <a>send to Craft Support</a>", "app");
            echo "</p>
            </form>
            <form class=\"cs-support-form hidden\" action=\"";
            // line 23
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::actionUrl("dashboard/send-support-request"), "html", null, true);
            echo "\" method=\"post\" target=\"";
            echo twig_escape_filter($this->env, ($context["idPrefix"] ?? null), "html", null, true);
            echo "-iframe\" accept-charset=\"UTF-8\" enctype=\"multipart/form-data\">
                ";
            // line 24
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->csrfInputFunction(), "html", null, true);
            echo "
                <input type=\"hidden\" name=\"widgetId\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["widget"] ?? null), "id", array()), "html", null, true);
            echo "\">
                <input class=\"cs-support-message\" type=\"hidden\" name=\"message\" value=\"\">

                ";
            // line 28
            $context["email"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["currentUser"] ?? null), "email", array());
            // line 29
            echo "                ";
            if (twig_in_filter(($context["email"] ?? null), array(0 => "support@pixelandtonic.com", 1 => "support@craftcms.com"))) {
                // line 30
                echo "                    ";
                $context["email"] = "";
                // line 31
                echo "                ";
            }
            // line 32
            echo "
                ";
            // line 33
            echo $context["forms"]->macro_textField(array("first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Your Email", "app"), "name" => "fromEmail", "value" =>             // line 37
($context["email"] ?? null)));
            // line 38
            echo "

                <a class=\"fieldtoggle\" data-target=\"";
            // line 40
            echo twig_escape_filter($this->env, ($context["idPrefix"] ?? null), "html", null, true);
            echo "-support-more\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("More", "app"), "html", null, true);
            echo "</a>

                <div id=\"";
            // line 42
            echo twig_escape_filter($this->env, ($context["idPrefix"] ?? null), "html", null, true);
            echo "-support-more\" class=\"cs-support-more hidden\">
                    ";
            // line 43
            echo $context["forms"]->macro_checkboxField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Attach error logs?", "app"), "name" => "attachLogs", "checked" => true));
            // line 47
            echo "

                    ";
            // line 49
            if (($context["showBackupOption"] ?? null)) {
                // line 50
                echo "                        ";
                echo $context["forms"]->macro_checkboxField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Attach a database backup?", "app"), "name" => "attachDbBackup", "checked" => true));
                // line 54
                echo "
                    ";
            }
            // line 56
            echo "
                    ";
            // line 57
            echo $context["forms"]->macro_checkboxField(array("name" => "attachTemplates", "checked" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Include your template files?", "app")));
            // line 61
            echo "

                    ";
            // line 63
            echo $context["forms"]->macro_fileField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Attach an additional file?", "app"), "class" => "cs-support-attachment", "name" => "attachAdditionalFile"));
            // line 67
            echo "
                </div>

                <input type=\"submit\" class=\"btn submit fullwidth disabled\" value=\"";
            // line 70
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Send", "app"), "html", null, true);
            echo "\">
                <div class=\"spinner hidden\"></div>
            </form>
        </div>
        <iframe id=\"";
            // line 74
            echo twig_escape_filter($this->env, ($context["idPrefix"] ?? null), "html", null, true);
            echo "-iframe\" name=\"";
            echo twig_escape_filter($this->env, ($context["idPrefix"] ?? null), "html", null, true);
            echo "-iframe\" class=\"hidden\"></iframe>
    </div>
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_components/widgets/CraftSupport/body";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 74,  219 => 70,  214 => 67,  212 => 63,  208 => 61,  206 => 57,  203 => 56,  199 => 54,  196 => 50,  194 => 49,  190 => 47,  188 => 43,  184 => 42,  177 => 40,  173 => 38,  171 => 37,  170 => 33,  167 => 32,  164 => 31,  161 => 30,  158 => 29,  156 => 28,  150 => 25,  146 => 24,  140 => 23,  135 => 21,  131 => 20,  126 => 18,  119 => 14,  115 => 13,  111 => 11,  109 => 9,  108 => 6,  102 => 5,  99 => 4,  96 => 3,  93 => 2,  74 => 1,  68 => 96,  63 => 94,  56 => 90,  52 => 89,  48 => 88,  42 => 85,  38 => 84,  34 => 83,  28 => 79,  26 => 78,  23 => 77,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_components/widgets/CraftSupport/body", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/_components/widgets/CraftSupport/body.html");
    }
}
