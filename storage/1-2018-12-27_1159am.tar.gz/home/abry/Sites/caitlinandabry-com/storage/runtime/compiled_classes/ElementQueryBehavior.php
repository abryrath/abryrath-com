<?php // vlHAaUncTD7hT
/**
 * @link http://craftcms.com/
 * @copyright Copyright (c) Pixel & Tonic, Inc.
 * @license http://craftcms.com/license
 */

namespace craft\behaviors;

/**
 * Element Query behavior
 *
 * This class provides attributes for all the unique custom field handles.
 *
 * @method self accommodationsContent(mixed $value) Sets the [[accommodationsContent]] property
 * @method self accommodationsIntroCopy(mixed $value) Sets the [[accommodationsIntroCopy]] property
 * @method self accommodationsTitle(mixed $value) Sets the [[accommodationsTitle]] property
 * @method self additionalInfo(mixed $value) Sets the [[additionalInfo]] property
 * @method self address(mixed $value) Sets the [[address]] property
 * @method self areas(mixed $value) Sets the [[areas]] property
 * @method self attractions(mixed $value) Sets the [[attractions]] property
 * @method self body(mixed $value) Sets the [[body]] property
 * @method self bodyParagraph(mixed $value) Sets the [[bodyParagraph]] property
 * @method self bridalParty(mixed $value) Sets the [[bridalParty]] property
 * @method self bridesmaidList(mixed $value) Sets the [[bridesmaidList]] property
 * @method self copy(mixed $value) Sets the [[copy]] property
 * @method self cuisineOld(mixed $value) Sets the [[cuisineOld]] property
 * @method self cuisines(mixed $value) Sets the [[cuisines]] property
 * @method self detailsContent(mixed $value) Sets the [[detailsContent]] property
 * @method self displayText(mixed $value) Sets the [[displayText]] property
 * @method self gettingAroundCopy(mixed $value) Sets the [[gettingAroundCopy]] property
 * @method self gettingAroundTitle(mixed $value) Sets the [[gettingAroundTitle]] property
 * @method self groomsmenList(mixed $value) Sets the [[groomsmenList]] property
 * @method self headline(mixed $value) Sets the [[headline]] property
 * @method self hotelAddress(mixed $value) Sets the [[hotelAddress]] property
 * @method self hotelDescription(mixed $value) Sets the [[hotelDescription]] property
 * @method self hotelImage(mixed $value) Sets the [[hotelImage]] property
 * @method self hotelPhone(mixed $value) Sets the [[hotelPhone]] property
 * @method self hotelRates(mixed $value) Sets the [[hotelRates]] property
 * @method self hotelsList(mixed $value) Sets the [[hotelsList]] property
 * @method self image(mixed $value) Sets the [[image]] property
 * @method self internalLink(mixed $value) Sets the [[internalLink]] property
 * @method self links(mixed $value) Sets the [[links]] property
 * @method self linkTitle(mixed $value) Sets the [[linkTitle]] property
 * @method self linkUrl(mixed $value) Sets the [[linkUrl]] property
 * @method self location(mixed $value) Sets the [[location]] property
 * @method self navMenu(mixed $value) Sets the [[navMenu]] property
 * @method self ourStoryContent(mixed $value) Sets the [[ourStoryContent]] property
 * @method self page(mixed $value) Sets the [[page]] property
 * @method self pageHeroImage(mixed $value) Sets the [[pageHeroImage]] property
 * @method self parkingRate(mixed $value) Sets the [[parkingRate]] property
 * @method self photos(mixed $value) Sets the [[photos]] property
 * @method self restaurantAddress(mixed $value) Sets the [[restaurantAddress]] property
 * @method self restaurantCost(mixed $value) Sets the [[restaurantCost]] property
 * @method self restaurantDescription(mixed $value) Sets the [[restaurantDescription]] property
 * @method self restaurantEpicentre(mixed $value) Sets the [[restaurantEpicentre]] property
 * @method self restaurantProximity(mixed $value) Sets the [[restaurantProximity]] property
 * @method self restaurants(mixed $value) Sets the [[restaurants]] property
 * @method self roomRate(mixed $value) Sets the [[roomRate]] property
 * @method self roomType(mixed $value) Sets the [[roomType]] property
 * @method self sectionHeading(mixed $value) Sets the [[sectionHeading]] property
 * @method self travelAccordion(mixed $value) Sets the [[travelAccordion]] property
 * @method self travelContent(mixed $value) Sets the [[travelContent]] property
 * @method self travelTitle(mixed $value) Sets the [[travelTitle]] property
 * @method self travelTypeAddress(mixed $value) Sets the [[travelTypeAddress]] property
 * @method self travelTypeDescription(mixed $value) Sets the [[travelTypeDescription]] property
 * @method self travelTypePhone(mixed $value) Sets the [[travelTypePhone]] property
 * @method self travelTypes(mixed $value) Sets the [[travelTypes]] property
 * @method self weddingPartyMemberName(mixed $value) Sets the [[weddingPartyMemberName]] property
 * @method self weddingPartyMemberPicture(mixed $value) Sets the [[weddingPartyMemberPicture]] property
 * @method self weddingPartyMemberPosition(mixed $value) Sets the [[weddingPartyMemberPosition]] property
 * @method self weddingPartyMemberRelation(mixed $value) Sets the [[weddingPartyMemberRelation]] property
 * @method self wysiwyg(mixed $value) Sets the [[wysiwyg]] property
 */
class ElementQueryBehavior extends ContentBehavior
{
    // Public Methods
    // =========================================================================

    /**
     * @inheritdoc
     */
    public function __call($name, $params)
    {
        if (isset(self::$fieldHandles[$name]) && count($params) === 1) {
            $this->$name = $params[0];
            return $this->owner;
        }
        return parent::__call($name, $params);
    }

    /**
     * @inheritdoc
     */
    public function hasMethod($name)
    {
        if (isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::hasMethod($name);
    }
}
