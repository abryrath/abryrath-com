<?php

/* wedding-party/_index */
class __TwigTemplate_5b0e0e5f7417a6c8bbb15cef04e9ff7c7baf3539615c37aa7ccc7a5831062b1b extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/default", "wedding-party/_index", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/default";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $cacheService = Craft::$app->getTemplateCaches();
        $request = Craft::$app->getRequest();
        $ignoreCache1 = ($request->getIsLivePreview() || $request->getToken() || ((getenv("APP_ENV") == "development")));
        if (!$ignoreCache1) {
            $cacheKey1 = "oydF5Cka5Yr3MD1zzyQbo88UXLTF7tjjuawc";
            $cacheBody1 = $cacheService->getTemplateCache($cacheKey1, true);
        } else {
            $cacheBody1 = null;
        }
        if ($cacheBody1 === null) {
            if (!$ignoreCache1) {
                $cacheService->startTemplateCache($cacheKey1);
            }
            ob_start();
            // line 5
            echo "    <div class=\"content\">
        ";
            // line 6
            $this->loadTemplate("_partials/wysiwyg", "wedding-party/_index", 6)->display(array("content" => array("sectionHeading" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 8
($context["entry"] ?? null), "headline", array()), "copy" => "")));
            // line 13
            echo "
        <div class=\"WeddingParty\">
            <div class=\"WeddingParty-col\">
                ";
            // line 16
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "bridesmaidList", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["bridesmaid"]) {
                // line 17
                echo "                    ";
                $this->loadTemplate("wedding-party/person", "wedding-party/_index", 17)->display(array("member" =>                 // line 18
$context["bridesmaid"]));
                // line 20
                echo "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['bridesmaid'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 21
            echo "            </div>
            <div class=\"WeddingParty-col\">
                ";
            // line 23
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "groomsmenList", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["groomsman"]) {
                // line 24
                echo "                    ";
                $this->loadTemplate("wedding-party/person", "wedding-party/_index", 24)->display(array("member" =>                 // line 25
$context["groomsman"]));
                // line 27
                echo "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['groomsman'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 28
            echo "            </div>
        </div>
    </div>
    ";
            $cacheBody1 = ob_get_clean();
            if (!$ignoreCache1) {
                $cacheService->endTemplateCache($cacheKey1, true, null, null, $cacheBody1);
            }
        }
        echo $cacheBody1;
    }

    public function getTemplateName()
    {
        return "wedding-party/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 28,  88 => 27,  86 => 25,  84 => 24,  80 => 23,  76 => 21,  70 => 20,  68 => 18,  66 => 17,  62 => 16,  57 => 13,  55 => 8,  54 => 6,  51 => 5,  35 => 4,  32 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "wedding-party/_index", "/home/abry/Sites/caitlinandabry-com/templates/wedding-party/_index.twig");
    }
}
