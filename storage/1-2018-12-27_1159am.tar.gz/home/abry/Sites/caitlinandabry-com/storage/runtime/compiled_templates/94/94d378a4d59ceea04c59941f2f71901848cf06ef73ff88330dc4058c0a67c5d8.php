<?php

/* _partials/nav-menu/subMenu */
class __TwigTemplate_30b8e56ce0a30730c8e50e344f2dab0edf7abdd742a4a1cc05f3ad8108a04acc extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<li class=\"Menu-item\" data-nav-parent=\"";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["link"] ?? null), "id", array()), "html", null, true);
        echo "\">
    <span>
        ";
        // line 3
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["link"] ?? null), "displayText", array()), "html", null, true);
        echo "
    </span>
    <div class=\"Menu-item-subMenu\" data-nav-child=\"";
        // line 5
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["link"] ?? null), "id", array()), "html", null, true);
        echo "\">
        ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["link"] ?? null), "internalLink", array()), "all", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 7
            echo "            <div>
                <a href=\"";
            // line 8
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["child"], "page", array()), "one", array()), "url", array()), "html", null, true);
            echo "\">
                    ";
            // line 9
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["child"], "displayText", array()), "html", null, true);
            echo "
                </a>
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "    </div>
</li>";
    }

    public function getTemplateName()
    {
        return "_partials/nav-menu/subMenu";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 13,  49 => 9,  45 => 8,  42 => 7,  38 => 6,  34 => 5,  29 => 3,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_partials/nav-menu/subMenu", "/home/abry/Sites/caitlinandabry-com/templates/_partials/nav-menu/subMenu.twig");
    }
}
