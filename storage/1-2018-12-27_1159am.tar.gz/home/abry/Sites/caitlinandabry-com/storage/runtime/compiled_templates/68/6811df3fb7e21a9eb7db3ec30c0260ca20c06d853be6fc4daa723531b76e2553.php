<?php

/* _includes/forms/checkbox */
class __TwigTemplate_53d622b7a60246196ca3f5b5327306dc6860e16a23573df97bdace508d533cfa extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        ob_start();
        // line 2
        echo "
";
        // line 3
        $context["class"] = twig_join_filter(array_filter(array(0 => ((        // line 4
(isset($context["class"]) || array_key_exists("class", $context))) ? (($context["class"] ?? null)) : (null)), 1 => ((((        // line 5
(isset($context["toggle"]) || array_key_exists("toggle", $context)) &&  !twig_test_empty(($context["toggle"] ?? null))) || ((isset($context["reverseToggle"]) || array_key_exists("reverseToggle", $context)) &&  !twig_test_empty(($context["reverseToggle"] ?? null))))) ? ("fieldtoggle") : (null)), 2 => "checkbox")), " ");
        // line 8
        echo "
";
        // line 9
        $context["value"] = (((isset($context["value"]) || array_key_exists("value", $context))) ? (($context["value"] ?? null)) : (1));
        // line 10
        $context["id"] = ((((isset($context["id"]) || array_key_exists("id", $context)) && ($context["id"] ?? null))) ? (($context["id"] ?? null)) : (("checkbox" . twig_random($this->env))));
        // line 11
        $context["label"] = (((isset($context["label"]) || array_key_exists("label", $context))) ? (($context["label"] ?? null)) : (""));
        // line 12
        echo "
";
        // line 13
        if (((isset($context["name"]) || array_key_exists("name", $context)) && ((twig_length_filter($this->env, ($context["name"] ?? null)) < 3) || (twig_slice($this->env, ($context["name"] ?? null),  -2) != "[]")))) {
            // line 14
            echo "    <input type=\"hidden\" name=\"";
            echo twig_escape_filter($this->env, ($context["name"] ?? null), "html", null, true);
            echo "\" value=\"\">
";
        }
        // line 16
        echo "
<input type=\"checkbox\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, ($context["value"] ?? null), "html", null, true);
        echo "\" class=\"";
        echo twig_escape_filter($this->env, ($context["class"] ?? null), "html", null, true);
        echo "\"";
        // line 18
        if (($context["id"] ?? null)) {
            echo " id=\"";
            echo twig_escape_filter($this->env, ($context["id"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 19
        if ((isset($context["name"]) || array_key_exists("name", $context))) {
            echo " name=\"";
            echo twig_escape_filter($this->env, ($context["name"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 20
        if (((isset($context["checked"]) || array_key_exists("checked", $context)) && ($context["checked"] ?? null))) {
            echo " checked";
        }
        // line 21
        if ((((isset($context["autofocus"]) || array_key_exists("autofocus", $context)) && ($context["autofocus"] ?? null)) &&  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "isMobileBrowser", array(0 => true), "method"))) {
            echo " autofocus";
        }
        // line 22
        if (((isset($context["disabled"]) || array_key_exists("disabled", $context)) && ($context["disabled"] ?? null))) {
            echo " disabled";
        }
        // line 23
        if ((isset($context["toggle"]) || array_key_exists("toggle", $context))) {
            echo " data-target=\"";
            echo twig_escape_filter($this->env, ($context["toggle"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 24
        if ((isset($context["reverseToggle"]) || array_key_exists("reverseToggle", $context))) {
            echo " data-reverse-target=\"";
            echo twig_escape_filter($this->env, ($context["reverseToggle"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 25
        if (        $this->hasBlock("attr", $context, $blocks)) {
            echo " ";
            $this->displayBlock("attr", $context, $blocks);
        }
        echo ">

<label for=\"";
        // line 27
        echo twig_escape_filter($this->env, ($context["id"] ?? null), "html", null, true);
        echo "\">";
        echo ($context["label"] ?? null);
        echo "</label>

";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    public function getTemplateName()
    {
        return "_includes/forms/checkbox";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 27,  96 => 25,  90 => 24,  84 => 23,  80 => 22,  76 => 21,  72 => 20,  66 => 19,  60 => 18,  55 => 17,  52 => 16,  46 => 14,  44 => 13,  41 => 12,  39 => 11,  37 => 10,  35 => 9,  32 => 8,  30 => 5,  29 => 4,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_includes/forms/checkbox", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/_includes/forms/checkbox.html");
    }
}
