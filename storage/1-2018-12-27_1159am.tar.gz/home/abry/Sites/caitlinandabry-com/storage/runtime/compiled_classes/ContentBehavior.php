<?php // vlHAaUncTD7hT
/**
 * @link http://craftcms.com/
 * @copyright Copyright (c) Pixel & Tonic, Inc.
 * @license http://craftcms.com/license
 */

namespace craft\behaviors;

use yii\base\Behavior;

/**
 * Content behavior
 *
 * This class provides attributes for all the unique custom field handles.
 */
class ContentBehavior extends Behavior
{
    // Static
    // =========================================================================

    /**
     * @var string[] List of supported field handles.
     */
    public static $fieldHandles = [
        'accommodationsContent' => true,
        'accommodationsIntroCopy' => true,
        'accommodationsTitle' => true,
        'additionalInfo' => true,
        'address' => true,
        'areas' => true,
        'attractions' => true,
        'body' => true,
        'bodyParagraph' => true,
        'bridalParty' => true,
        'bridesmaidList' => true,
        'copy' => true,
        'cuisineOld' => true,
        'cuisines' => true,
        'detailsContent' => true,
        'displayText' => true,
        'gettingAroundCopy' => true,
        'gettingAroundTitle' => true,
        'groomsmenList' => true,
        'headline' => true,
        'hotelAddress' => true,
        'hotelDescription' => true,
        'hotelImage' => true,
        'hotelPhone' => true,
        'hotelRates' => true,
        'hotelsList' => true,
        'image' => true,
        'internalLink' => true,
        'links' => true,
        'linkTitle' => true,
        'linkUrl' => true,
        'location' => true,
        'navMenu' => true,
        'ourStoryContent' => true,
        'page' => true,
        'pageHeroImage' => true,
        'parkingRate' => true,
        'photos' => true,
        'restaurantAddress' => true,
        'restaurantCost' => true,
        'restaurantDescription' => true,
        'restaurantEpicentre' => true,
        'restaurantProximity' => true,
        'restaurants' => true,
        'roomRate' => true,
        'roomType' => true,
        'sectionHeading' => true,
        'travelAccordion' => true,
        'travelContent' => true,
        'travelTitle' => true,
        'travelTypeAddress' => true,
        'travelTypeDescription' => true,
        'travelTypePhone' => true,
        'travelTypes' => true,
        'weddingPartyMemberName' => true,
        'weddingPartyMemberPicture' => true,
        'weddingPartyMemberPosition' => true,
        'weddingPartyMemberRelation' => true,
        'wysiwyg' => true,
    ];

    // Properties
    // =========================================================================

    /**
     * @var mixed Value for field with the handle “accommodationsContent”.
     */
    public $accommodationsContent;

    /**
     * @var mixed Value for field with the handle “accommodationsIntroCopy”.
     */
    public $accommodationsIntroCopy;

    /**
     * @var mixed Value for field with the handle “accommodationsTitle”.
     */
    public $accommodationsTitle;

    /**
     * @var mixed Value for field with the handle “additionalInfo”.
     */
    public $additionalInfo;

    /**
     * @var mixed Value for field with the handle “address”.
     */
    public $address;

    /**
     * @var mixed Value for field with the handle “areas”.
     */
    public $areas;

    /**
     * @var mixed Value for field with the handle “attractions”.
     */
    public $attractions;

    /**
     * @var mixed Value for field with the handle “body”.
     */
    public $body;

    /**
     * @var mixed Value for field with the handle “bodyParagraph”.
     */
    public $bodyParagraph;

    /**
     * @var mixed Value for field with the handle “bridalParty”.
     */
    public $bridalParty;

    /**
     * @var mixed Value for field with the handle “bridesmaidList”.
     */
    public $bridesmaidList;

    /**
     * @var mixed Value for field with the handle “copy”.
     */
    public $copy;

    /**
     * @var mixed Value for field with the handle “cuisineOld”.
     */
    public $cuisineOld;

    /**
     * @var mixed Value for field with the handle “cuisines”.
     */
    public $cuisines;

    /**
     * @var mixed Value for field with the handle “detailsContent”.
     */
    public $detailsContent;

    /**
     * @var mixed Value for field with the handle “displayText”.
     */
    public $displayText;

    /**
     * @var mixed Value for field with the handle “gettingAroundCopy”.
     */
    public $gettingAroundCopy;

    /**
     * @var mixed Value for field with the handle “gettingAroundTitle”.
     */
    public $gettingAroundTitle;

    /**
     * @var mixed Value for field with the handle “groomsmenList”.
     */
    public $groomsmenList;

    /**
     * @var mixed Value for field with the handle “headline”.
     */
    public $headline;

    /**
     * @var mixed Value for field with the handle “hotelAddress”.
     */
    public $hotelAddress;

    /**
     * @var mixed Value for field with the handle “hotelDescription”.
     */
    public $hotelDescription;

    /**
     * @var mixed Value for field with the handle “hotelImage”.
     */
    public $hotelImage;

    /**
     * @var mixed Value for field with the handle “hotelPhone”.
     */
    public $hotelPhone;

    /**
     * @var mixed Value for field with the handle “hotelRates”.
     */
    public $hotelRates;

    /**
     * @var mixed Value for field with the handle “hotelsList”.
     */
    public $hotelsList;

    /**
     * @var mixed Value for field with the handle “image”.
     */
    public $image;

    /**
     * @var mixed Value for field with the handle “internalLink”.
     */
    public $internalLink;

    /**
     * @var mixed Value for field with the handle “links”.
     */
    public $links;

    /**
     * @var mixed Value for field with the handle “linkTitle”.
     */
    public $linkTitle;

    /**
     * @var mixed Value for field with the handle “linkUrl”.
     */
    public $linkUrl;

    /**
     * @var mixed Value for field with the handle “location”.
     */
    public $location;

    /**
     * @var mixed Value for field with the handle “navMenu”.
     */
    public $navMenu;

    /**
     * @var mixed Value for field with the handle “ourStoryContent”.
     */
    public $ourStoryContent;

    /**
     * @var mixed Value for field with the handle “page”.
     */
    public $page;

    /**
     * @var mixed Value for field with the handle “pageHeroImage”.
     */
    public $pageHeroImage;

    /**
     * @var mixed Value for field with the handle “parkingRate”.
     */
    public $parkingRate;

    /**
     * @var mixed Value for field with the handle “photos”.
     */
    public $photos;

    /**
     * @var mixed Value for field with the handle “restaurantAddress”.
     */
    public $restaurantAddress;

    /**
     * @var mixed Value for field with the handle “restaurantCost”.
     */
    public $restaurantCost;

    /**
     * @var mixed Value for field with the handle “restaurantDescription”.
     */
    public $restaurantDescription;

    /**
     * @var mixed Value for field with the handle “restaurantEpicentre”.
     */
    public $restaurantEpicentre;

    /**
     * @var mixed Value for field with the handle “restaurantProximity”.
     */
    public $restaurantProximity;

    /**
     * @var mixed Value for field with the handle “restaurants”.
     */
    public $restaurants;

    /**
     * @var mixed Value for field with the handle “roomRate”.
     */
    public $roomRate;

    /**
     * @var mixed Value for field with the handle “roomType”.
     */
    public $roomType;

    /**
     * @var mixed Value for field with the handle “sectionHeading”.
     */
    public $sectionHeading;

    /**
     * @var mixed Value for field with the handle “travelAccordion”.
     */
    public $travelAccordion;

    /**
     * @var mixed Value for field with the handle “travelContent”.
     */
    public $travelContent;

    /**
     * @var mixed Value for field with the handle “travelTitle”.
     */
    public $travelTitle;

    /**
     * @var mixed Value for field with the handle “travelTypeAddress”.
     */
    public $travelTypeAddress;

    /**
     * @var mixed Value for field with the handle “travelTypeDescription”.
     */
    public $travelTypeDescription;

    /**
     * @var mixed Value for field with the handle “travelTypePhone”.
     */
    public $travelTypePhone;

    /**
     * @var mixed Value for field with the handle “travelTypes”.
     */
    public $travelTypes;

    /**
     * @var mixed Value for field with the handle “weddingPartyMemberName”.
     */
    public $weddingPartyMemberName;

    /**
     * @var mixed Value for field with the handle “weddingPartyMemberPicture”.
     */
    public $weddingPartyMemberPicture;

    /**
     * @var mixed Value for field with the handle “weddingPartyMemberPosition”.
     */
    public $weddingPartyMemberPosition;

    /**
     * @var mixed Value for field with the handle “weddingPartyMemberRelation”.
     */
    public $weddingPartyMemberRelation;

    /**
     * @var mixed Value for field with the handle “wysiwyg”.
     */
    public $wysiwyg;

    /**
     * @var array Additional custom field values we don’t know about yet.
     */
    private $_customFieldValues = [];

    // Magic Property Methods
    // =========================================================================

    /**
     * @inheritdoc
     */
    public function __isset($name)
    {
        if (isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::__isset($name);
    }

    /**
     * @inheritdoc
     */
    public function __get($name)
    {
        if (isset(self::$fieldHandles[$name])) {
            return $this->_customFieldValues[$name] ?? null;
        }
        return parent::__get($name);
    }

    /**
     * @inheritdoc
     */
    public function __set($name, $value)
    {
        if (isset(self::$fieldHandles[$name])) {
            $this->_customFieldValues[$name] = $value;
            return;
        }
        parent::__set($name, $value);
    }

    /**
     * @inheritdoc
     */
    public function canGetProperty($name, $checkVars = true)
    {
        if ($checkVars && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::canGetProperty($name, $checkVars);
    }

    /**
     * @inheritdoc
     */
    public function canSetProperty($name, $checkVars = true)
    {
        if ($checkVars && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::canSetProperty($name, $checkVars);
    }
}
