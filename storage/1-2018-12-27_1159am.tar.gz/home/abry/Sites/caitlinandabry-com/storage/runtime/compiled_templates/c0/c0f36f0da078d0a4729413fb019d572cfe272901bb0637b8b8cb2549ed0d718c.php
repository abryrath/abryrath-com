<?php

/* _layouts/cp */
class __TwigTemplate_04702b0baa20e1c882205ad3f183db83c16855b2a4eba8fc73992edbee2d11e8 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 44
        $this->parent = $this->loadTemplate("_layouts/basecp", "_layouts/cp", 44);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'mainFormAttributes' => array($this, 'block_mainFormAttributes'),
            'header' => array($this, 'block_header'),
            'pageTitle' => array($this, 'block_pageTitle'),
            'contextMenu' => array($this, 'block_contextMenu'),
            'actionButton' => array($this, 'block_actionButton'),
            'main' => array($this, 'block_main'),
            'tabs' => array($this, 'block_tabs'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/basecp";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 47
        $context["queue"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "queue", array());
        // line 48
        ob_start();
        // line 49
        echo "    ";
        if (call_user_func_array($this->env->getTest('instance of')->getCallable(), array(($context["queue"] ?? null), "craft\\queue\\QueueInterface"))) {
            // line 50
            echo "        Craft.cp.setJobInfo(";
            echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["queue"] ?? null), "getJobInfo", array(0 => 100), "method"));
            echo ", false);
        ";
            // line 51
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["queue"] ?? null), "getHasReservedJobs", array(), "method")) {
                // line 52
                echo "            Craft.cp.trackJobProgress(true);
        ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 53
($context["queue"] ?? null), "getHasWaitingJobs", array(), "method")) {
                // line 54
                echo "            Craft.cp.runQueue();
        ";
            }
            // line 56
            echo "    ";
        } else {
            // line 57
            echo "        Craft.cp.enableQueue = false;
    ";
        }
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 61
        $context["hasSystemIcon"] = ((($context["CraftEdition"] ?? null) == ($context["CraftPro"] ?? null)) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "rebrand", array()), "isIconUploaded", array()));
        // line 63
        $context["forceConfirmUnload"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "session", array()), "hasFlash", array(0 => "error"), "method");
        // line 64
        $context["fullPageForm"] = ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context)) && ($context["fullPageForm"] ?? null));
        // line 66
        $context["canUpgradeEdition"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "getCanUpgradeEdition", array(), "method");
        // line 67
        $context["licensedEdition"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "getLicensedEdition", array(), "method");
        // line 68
        $context["isTrial"] = ( !(($context["licensedEdition"] ?? null) === null) &&  !(($context["licensedEdition"] ?? null) === ($context["CraftEdition"] ?? null)));
        // line 70
        $context["sidebar"] = twig_trim_filter((($context["sidebar"]) ?? ((((        $this->hasBlock("sidebar", $context, $blocks) &&  !(null ===         $this->renderBlock("sidebar", $context, $blocks)))) ? (        $this->renderBlock("sidebar", $context, $blocks)) : ("")))));
        // line 71
        $context["details"] = twig_trim_filter((($context["details"]) ?? ((((        $this->hasBlock("details", $context, $blocks) &&  !(null ===         $this->renderBlock("details", $context, $blocks)))) ? (        $this->renderBlock("details", $context, $blocks)) : ("")))));
        // line 72
        $context["crumbs"] = (($context["crumbs"]) ?? (null));
        // line 284
        if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["currentUser"] ?? null), "can", array(0 => "performUpdates"), "method") &&  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "updates", array()), "getIsUpdateInfoCached", array(), "method"))) {
            // line 285
            ob_start();
            // line 286
            echo "        Craft.cp.checkForUpdates();
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
        // line 44
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 74
    public function block_body($context, array $blocks = array())
    {
        // line 75
        echo "    <div id=\"global-container\">
        <header id=\"global-sidebar\" class=\"sidebar\">
            ";
        // line 77
        if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["currentUser"] ?? null), "admin", array()) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "config", array()), "general", array()), "devMode", array()))) {
            // line 78
            echo "                <div id=\"devmode\" title=\"";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Craft CMS is running in Dev Mode.", "app"), "html", null, true);
            echo "\"></div>
            ";
        }
        // line 80
        echo "
            <a id=\"system-info\" class=\"menubtn\" role=\"button\" data-menu-anchor=\"#user-info\">
                <div id=\"site-icon\">
                    ";
        // line 83
        if (($context["hasSystemIcon"] ?? null)) {
            // line 84
            echo "                        <img src=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "rebrand", array()), "icon", array()), "url", array()), "html", null, true);
            echo "\" alt=\"\">
                    ";
        } else {
            // line 86
            echo "                        ";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->svgFunction("@app/icons/circle-c-outline.svg", null, true), "html", null, true);
            echo "
                    ";
        }
        // line 88
        echo "                </div>
                <div id=\"system-name\">
                    <h2>";
        // line 90
        echo twig_escape_filter($this->env, ($context["systemName"] ?? null), "html", null, true);
        echo "&nbsp;<span data-icon=\"downangle\"></span></h2>
                    <div id=\"user-info\">
                        ";
        // line 92
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["currentUser"] ?? null), "photoId", array())) {
            // line 93
            echo "                            <div id=\"user-photo\">
                                <img width=\"14\" sizes=\"14px\" srcset=\"";
            // line 94
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["currentUser"] ?? null), "getThumbUrl", array(0 => 14), "method"), "html", null, true);
            echo " 14w, ";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["currentUser"] ?? null), "getThumbUrl", array(0 => 28), "method"), "html", null, true);
            echo " 28w\" alt=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["currentUser"] ?? null), "getName", array(), "method"), "html", null, true);
            echo "\">
                            </div>
                        ";
        }
        // line 97
        echo "                        <div>";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["currentUser"] ?? null), "friendlyName", array()), "html", null, true);
        echo "</div>
                    </div>
                </div>
            </a>

            <div class=\"menu\" data-align=\"left\">
                <ul>
                    <li><a href=\"";
        // line 104
        echo twig_escape_filter($this->env, ($context["siteUrl"] ?? null), "html", null, true);
        echo "\" rel=\"noopener\" target=\"_blank\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("View site", "app"), "html", null, true);
        echo "</a></li>
                </ul>
                <hr>
                <ul>
                    <li><a href=\"";
        // line 108
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("myaccount"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("My Account", "app"), "html", null, true);
        echo "</a></li>
                    <li><a href=\"";
        // line 109
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("logout"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sign out", "app"), "html", null, true);
        echo "</a></li>
                </ul>
            </div>

            <nav id=\"nav\">
                <ul>
                    ";
        // line 115
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "cp", array()), "nav", array(), "method"));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 116
            echo "                        ";
            $context["hasSubnav"] = (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "subnav", array(), "any", true, true) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "subnav", array()));
            // line 117
            echo "                        <li id=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "id", array()), "html", null, true);
            echo "\" ";
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "sel", array()) && ($context["hasSubnav"] ?? null))) {
                echo " class=\"has-subnav\"";
            }
            echo ">
                            <a";
            // line 118
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "sel", array())) {
                echo " class=\"sel\"";
            }
            echo " href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "url", array()), "html", null, true);
            echo "\">
                                <span class=\"icon icon-mask\">";
            // line 120
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "icon", array(), "any", true, true)) {
                // line 121
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "icon", array()), true, true), "html", null, true);
            } elseif (craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 122
$context["item"], "fontIcon", array(), "any", true, true)) {
                // line 123
                echo "<span data-icon=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "fontIcon", array()), "html", null, true);
                echo "\"></span>";
            } else {
                // line 125
                $this->loadTemplate("_includes/defaulticon.svg", "_layouts/cp", 125)->display(array_merge($context, array("label" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "label", array()))));
            }
            // line 127
            echo "</span>

                                <span class=\"label\">";
            // line 130
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "label", array()), "html", null, true);
            // line 131
            echo "</span>";
            // line 133
            if (( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "sel", array()) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "badgeCount", array()))) {
                // line 134
                echo "<span class=\"badge\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "badgeCount", array()), "html", null, true);
                echo "</span>";
            }
            // line 136
            echo "</a>
                            ";
            // line 137
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "sel", array()) && ($context["hasSubnav"] ?? null))) {
                // line 138
                echo "                                <ul class=\"subnav\">
                                    ";
                // line 139
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "subnav", array()));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["itemId"] => $context["item"]) {
                    // line 140
                    echo "                                        ";
                    $context["itemIsSelected"] = ((                    // line 141
(isset($context["selectedSubnavItem"]) || array_key_exists("selectedSubnavItem", $context)) && (($context["selectedSubnavItem"] ?? null) == $context["itemId"])) || ( !                    // line 142
(isset($context["selectedSubnavItem"]) || array_key_exists("selectedSubnavItem", $context)) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "first", array())));
                    // line 145
                    echo "<li>
                                            <a href=\"";
                    // line 146
                    echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "url", array())), "html", null, true);
                    echo "\"";
                    if (($context["itemIsSelected"] ?? null)) {
                        echo " class=\"sel\"";
                    }
                    echo ">";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "label", array()), "html", null, true);
                    echo "</a>
                                        </li>

                                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['itemId'], $context['item'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 150
                echo "                                </ul>
                            ";
            }
            // line 152
            echo "                        </li>
                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 154
        echo "                </ul>
            </nav>

            <div id=\"app-info\">
                <div id=\"edition\" ";
        // line 158
        if (($context["canUpgradeEdition"] ?? null)) {
            echo "class=\"hot\" title=\"";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Manage your Craft CMS edition", "app"), "html", null, true);
            echo "\"";
        } else {
            echo "class=\"edition\"";
        }
        echo ">
                    <div id=\"edition-logo\">
                        <div class=\"edition-name\">";
        // line 160
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "getEditionName", array(), "method"), "html", null, true);
        echo "</div>
                        ";
        // line 161
        if (($context["isTrial"] ?? null)) {
            // line 162
            echo "                            <div class=\"edition-trial\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Trial", "app"), "html", null, true);
            echo "</div>
                        ";
        }
        // line 164
        echo "                    </div>
                </div>
                <div id=\"version\">Craft CMS ";
        // line 166
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "version", array()), "html", null, true);
        echo "</div>
            </div>
        </header><!-- #global-sidebar -->

        <div id=\"main-container\">

            ";
        // line 173
        echo "            ";
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "cp", array()), "areAlertsCached", array(), "method")) {
            // line 174
            echo "                ";
            $context["alerts"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "cp", array()), "getAlerts", array(), "method");
            // line 175
            echo "                ";
            if (($context["alerts"] ?? null)) {
                // line 176
                echo "                    <ul id=\"alerts\">
                        ";
                // line 177
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "cp", array()), "getAlerts", array(), "method"));
                foreach ($context['_seq'] as $context["_key"] => $context["alert"]) {
                    // line 178
                    echo "                            <li>";
                    echo $context["alert"];
                    echo "</li>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['alert'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 180
                echo "                    </ul>
                ";
            }
            // line 182
            echo "            ";
        } else {
            // line 183
            echo "                ";
            ob_start();
            // line 184
            echo "                Craft.cp.fetchAlerts();
                ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
            // line 186
            echo "            ";
        }
        // line 187
        echo "
            ";
        // line 189
        echo "            <div id=\"notifications-wrapper\">
                <div id=\"notifications\">
                    ";
        // line 191
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(array(0 => "notice", 1 => "error"));
        foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
            // line 192
            echo "                        ";
            $context["message"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "session", array()), "getFlash", array(0 => $context["type"]), "method");
            // line 193
            echo "                        ";
            if (($context["message"] ?? null)) {
                // line 194
                echo "                            <div class=\"notification ";
                echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, ($context["message"] ?? null), "html", null, true);
                echo "</div>
                        ";
            }
            // line 196
            echo "                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 197
        echo "                </div>
            </div>

            ";
        // line 201
        echo "            <div id=\"crumbs\"";
        if ( !($context["crumbs"] ?? null)) {
            echo " class=\"empty\"";
        }
        echo ">
                <a id=\"nav-toggle\" title=\"";
        // line 202
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Show nav", "app"), "html", null, true);
        echo "\"></a>
                ";
        // line 203
        if (($context["crumbs"] ?? null)) {
            // line 204
            echo "                    <nav>
                        <ul>
                            ";
            // line 206
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["crumbs"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["crumb"]) {
                // line 207
                echo "                                <li><a href=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["crumb"], "url", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["crumb"], "label", array()), "html", null, true);
                echo "</a></li>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['crumb'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 209
            echo "                        </ul>
                    </nav>
                ";
        }
        // line 212
        echo "            </div>

            ";
        // line 215
        echo "            <main id=\"main\" role=\"main\">

                ";
        // line 217
        if (($context["fullPageForm"] ?? null)) {
            // line 218
            echo "<form ";
            $this->displayBlock('mainFormAttributes', $context, $blocks);
            echo ">";
            // line 219
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->csrfInputFunction(), "html", null, true);
        }
        // line 221
        echo "
                ";
        // line 223
        echo "                <header id=\"header\">
                    ";
        // line 224
        $this->displayBlock('header', $context, $blocks);
        // line 238
        echo "                </header>

                ";
        // line 241
        echo "                <div id=\"main-content\" class=\"";
        if (($context["sidebar"] ?? null)) {
            echo "has-sidebar";
        }
        echo " ";
        if (($context["details"] ?? null)) {
            echo "has-details";
        }
        echo "\">
                    ";
        // line 242
        $this->displayBlock('main', $context, $blocks);
        // line 273
        echo "                </div>

                ";
        // line 275
        if (($context["fullPageForm"] ?? null)) {
            // line 276
            echo "</form><!-- #main-form -->";
        }
        // line 278
        echo "            </main><!-- #main -->
        </div><!-- #main-container -->
    </div><!-- #global-container -->
";
    }

    // line 218
    public function block_mainFormAttributes($context, array $blocks = array())
    {
        echo "id=\"main-form\" method=\"post\" accept-charset=\"UTF-8\" data-saveshortcut";
        if ((isset($context["saveShortcutRedirect"]) || array_key_exists("saveShortcutRedirect", $context))) {
            echo " data-saveshortcut-redirect=\"";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('hash')->getCallable(), array(($context["saveShortcutRedirect"] ?? null))), "html", null, true);
            echo "\"";
        }
        echo " data-confirm-unload novalidate";
    }

    // line 224
    public function block_header($context, array $blocks = array())
    {
        // line 225
        echo "                        ";
        $this->displayBlock('pageTitle', $context, $blocks);
        // line 230
        echo "                        ";
        $this->displayBlock('contextMenu', $context, $blocks);
        // line 231
        echo "                        <div class=\"flex-grow\"></div>
                        ";
        // line 232
        $this->displayBlock('actionButton', $context, $blocks);
        // line 237
        echo "                    ";
    }

    // line 225
    public function block_pageTitle($context, array $blocks = array())
    {
        // line 226
        echo "                            ";
        if (((isset($context["title"]) || array_key_exists("title", $context)) && twig_length_filter($this->env, ($context["title"] ?? null)))) {
            // line 227
            echo "                                <h1>";
            echo twig_escape_filter($this->env, ($context["title"] ?? null), "html", null, true);
            echo "</h1>
                            ";
        }
        // line 229
        echo "                        ";
    }

    // line 230
    public function block_contextMenu($context, array $blocks = array())
    {
    }

    // line 232
    public function block_actionButton($context, array $blocks = array())
    {
        // line 233
        echo "                            ";
        if (($context["fullPageForm"] ?? null)) {
            // line 234
            echo "                                <input type=\"submit\" class=\"btn submit\" value=\"";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"), "html", null, true);
            echo "\">
                            ";
        }
        // line 236
        echo "                        ";
    }

    // line 242
    public function block_main($context, array $blocks = array())
    {
        // line 243
        echo "                        ";
        // line 244
        echo "                        ";
        if ( !twig_test_empty(($context["sidebar"] ?? null))) {
            // line 245
            echo "                            <a id=\"sidebar-toggle\"><span id=\"selected-sidebar-item-label\"></span>&nbsp;<span data-icon=\"downangle\"></span></a>
                            <div id=\"sidebar\" class=\"sidebar\">
                                ";
            // line 247
            echo ($context["sidebar"] ?? null);
            echo "
                            </div>
                        ";
        }
        // line 250
        echo "
                        ";
        // line 252
        echo "                        <div id=\"content-container\">
                            ";
        // line 253
        $this->displayBlock('tabs', $context, $blocks);
        // line 258
        echo "
                            <div id=\"content\">
                                ";
        // line 260
        $this->displayBlock('content', $context, $blocks);
        // line 263
        echo "                            </div>
                        </div>

                        ";
        // line 267
        echo "                        ";
        if ( !twig_test_empty(($context["details"] ?? null))) {
            // line 268
            echo "                            <div id=\"details\">
                                ";
            // line 269
            echo ($context["details"] ?? null);
            echo "
                            </div>
                        ";
        }
        // line 272
        echo "                    ";
    }

    // line 253
    public function block_tabs($context, array $blocks = array())
    {
        // line 254
        echo "                                ";
        if (((isset($context["tabs"]) || array_key_exists("tabs", $context)) && ($context["tabs"] ?? null))) {
            // line 255
            echo "                                    ";
            $this->loadTemplate("_includes/tabs", "_layouts/cp", 255)->display($context);
            // line 256
            echo "                                ";
        }
        // line 257
        echo "                            ";
    }

    // line 260
    public function block_content($context, array $blocks = array())
    {
        // line 261
        echo "                                    ";
        echo twig_escape_filter($this->env, (((isset($context["content"]) || array_key_exists("content", $context))) ? (($context["content"] ?? null)) : ("")), "html", null, true);
        echo "
                                ";
    }

    public function getTemplateName()
    {
        return "_layouts/cp";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  690 => 261,  687 => 260,  683 => 257,  680 => 256,  677 => 255,  674 => 254,  671 => 253,  667 => 272,  661 => 269,  658 => 268,  655 => 267,  650 => 263,  648 => 260,  644 => 258,  642 => 253,  639 => 252,  636 => 250,  630 => 247,  626 => 245,  623 => 244,  621 => 243,  618 => 242,  614 => 236,  608 => 234,  605 => 233,  602 => 232,  597 => 230,  593 => 229,  587 => 227,  584 => 226,  581 => 225,  577 => 237,  575 => 232,  572 => 231,  569 => 230,  566 => 225,  563 => 224,  551 => 218,  544 => 278,  541 => 276,  539 => 275,  535 => 273,  533 => 242,  522 => 241,  518 => 238,  516 => 224,  513 => 223,  510 => 221,  507 => 219,  503 => 218,  501 => 217,  497 => 215,  493 => 212,  488 => 209,  477 => 207,  473 => 206,  469 => 204,  467 => 203,  463 => 202,  456 => 201,  451 => 197,  445 => 196,  437 => 194,  434 => 193,  431 => 192,  427 => 191,  423 => 189,  420 => 187,  417 => 186,  413 => 184,  410 => 183,  407 => 182,  403 => 180,  394 => 178,  390 => 177,  387 => 176,  384 => 175,  381 => 174,  378 => 173,  369 => 166,  365 => 164,  359 => 162,  357 => 161,  353 => 160,  342 => 158,  336 => 154,  321 => 152,  317 => 150,  293 => 146,  290 => 145,  288 => 142,  287 => 141,  285 => 140,  268 => 139,  265 => 138,  263 => 137,  260 => 136,  255 => 134,  253 => 133,  251 => 131,  249 => 130,  245 => 127,  242 => 125,  237 => 123,  235 => 122,  233 => 121,  231 => 120,  223 => 118,  214 => 117,  211 => 116,  194 => 115,  183 => 109,  177 => 108,  168 => 104,  157 => 97,  147 => 94,  144 => 93,  142 => 92,  137 => 90,  133 => 88,  127 => 86,  121 => 84,  119 => 83,  114 => 80,  108 => 78,  106 => 77,  102 => 75,  99 => 74,  95 => 44,  90 => 286,  88 => 285,  86 => 284,  84 => 72,  82 => 71,  80 => 70,  78 => 68,  76 => 67,  74 => 66,  72 => 64,  70 => 63,  68 => 61,  63 => 57,  60 => 56,  56 => 54,  54 => 53,  51 => 52,  49 => 51,  44 => 50,  41 => 49,  39 => 48,  37 => 47,  15 => 44,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_layouts/cp", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/_layouts/cp.html");
    }
}
