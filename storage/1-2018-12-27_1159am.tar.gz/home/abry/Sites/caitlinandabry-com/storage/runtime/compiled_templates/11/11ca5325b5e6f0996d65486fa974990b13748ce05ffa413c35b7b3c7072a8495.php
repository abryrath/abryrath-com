<?php

/* _partials/image */
class __TwigTemplate_d5fd69813aff47b73cecaca4829b5fb23b7d579571274375d90300568647b12b extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"Image\">
    <img src=\"";
        // line 2
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["content"] ?? null), "image", array()), "one", array()), "url", array()), "html", null, true);
        echo "\">
</div>";
    }

    public function getTemplateName()
    {
        return "_partials/image";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_partials/image", "/home/abry/Sites/caitlinandabry-com/templates/_partials/image.twig");
    }
}
