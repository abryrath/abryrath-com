<?php

/* details/_entry */
class __TwigTemplate_a9fccdae56c69c5c2caceccee5e6612ea71f2e0e788087a87808319f13919228 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/default", "details/_entry", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/default";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        // line 5
        echo "        ";
        $context["hero"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "pageHeroImage", array());
        // line 6
        echo "        ";
        if (twig_length_filter($this->env, ($context["hero"] ?? null))) {
            // line 7
            echo "            <div class=\"Hero\">
                <img src=\"";
            // line 8
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["hero"] ?? null), "one", array()), "getUrl", array()), "html", null, true);
            echo "\"/>
            </div>
        ";
        }
        // line 11
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "detailsContent", array()), "all", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["content"]) {
            // line 12
            echo "            ";
            $this->loadTemplate(("_partials/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["content"], "type", array()), "handle", array())), "details/_entry", 12)->display(array("content" =>             // line 13
$context["content"]));
            // line 15
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['content'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "    ";
    }

    public function getTemplateName()
    {
        return "details/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 16,  61 => 15,  59 => 13,  57 => 12,  52 => 11,  46 => 8,  43 => 7,  40 => 6,  37 => 5,  35 => 4,  32 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "details/_entry", "/home/abry/Sites/caitlinandabry-com/templates/details/_entry.twig");
    }
}
