<?php

/* _components/utilities/SystemReport */
class __TwigTemplate_2650dcc3360c8e7418444d58d9ed90a1da1a59302c17eb4ae0c75677f494f366 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"readable\">
    <h2>";
        // line 2
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Application Info", "app"), "html", null, true);
        echo "</h2>

    <table class=\"data fullwidth fixed-layout\">
        <tbody>
            ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["appInfo"] ?? null));
        foreach ($context['_seq'] as $context["label"] => $context["value"]) {
            // line 7
            echo "                <tr>
                    <th class=\"light\">";
            // line 8
            echo twig_escape_filter($this->env, $context["label"], "html", null, true);
            echo "</th>
                    <td>";
            // line 9
            echo twig_escape_filter($this->env, $context["value"], "html", null, true);
            echo "</td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['label'], $context['value'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 12
        echo "        </tbody>
    </table>

    <h2>";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Plugins", "app"), "html", null, true);
        echo "</h2>

    ";
        // line 17
        if (twig_length_filter($this->env, ($context["plugins"] ?? null))) {
            // line 18
            echo "        <table class=\"data fullwidth fixed-layout\">
            <tbody>
                ";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["plugins"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["plugin"]) {
                // line 21
                echo "                    <tr>
                        <th class=\"light\">";
                // line 22
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["plugin"], "name", array()), "html", null, true);
                echo "</th>
                        <td>";
                // line 23
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["plugin"], "version", array()), "html", null, true);
                echo "</td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['plugin'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 26
            echo "            </tbody>
        </table>
    ";
        } else {
            // line 29
            echo "        <p>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("No plugins are enabled.", "app"), "html", null, true);
            echo "</p>
    ";
        }
        // line 31
        echo "
    <h2>";
        // line 32
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Modules", "app"), "html", null, true);
        echo "</h2>

    ";
        // line 34
        if (twig_length_filter($this->env, ($context["modules"] ?? null))) {
            // line 35
            echo "        <table class=\"data fullwidth fixed-layout\">
            <tbody>
                ";
            // line 37
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["modules"] ?? null));
            foreach ($context['_seq'] as $context["id"] => $context["class"]) {
                // line 38
                echo "                    <tr>
                        <th class=\"light\">";
                // line 39
                echo twig_escape_filter($this->env, $context["id"], "html", null, true);
                echo "</th>
                        <td>";
                // line 40
                echo twig_escape_filter($this->env, $context["class"], "html", null, true);
                echo "</td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['id'], $context['class'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 43
            echo "            </tbody>
        </table>
    ";
        } else {
            // line 46
            echo "        <p>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("No modules are installed.", "app"), "html", null, true);
            echo "</p>
    ";
        }
        // line 48
        echo "
    <h2>";
        // line 49
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Requirements", "app"), "html", null, true);
        echo "</h2>

    <table class=\"data fullwidth\">
        <tbody>
        ";
        // line 53
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["requirements"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["requirement"]) {
            // line 54
            echo "            <tr>
                <td class=\"thin centeralign\">
                    ";
            // line 56
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["requirement"], "error", array())) {
                // line 57
                echo "                        <span class=\"error\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Failed", "app"), "html", null, true);
                echo "\" data-icon=\"error\"></span>
                    ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 58
$context["requirement"], "warning", array())) {
                // line 59
                echo "                        <span class=\"warning\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Passed with warning", "app"), "html", null, true);
                echo "\" data-icon=\"alert\"></span>
                    ";
            } else {
                // line 61
                echo "                        <span class=\"success\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Passed", "app"), "html", null, true);
                echo "\" data-icon=\"check\"></span>
                    ";
            }
            // line 63
            echo "                </td>
                <td>";
            // line 64
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["requirement"], "name", array()), "html", null, true);
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["requirement"], "memo", array())) {
                echo " <span class=\"info\">";
                echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["requirement"], "memo", array());
                echo "</span>";
            }
            echo "</td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['requirement'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 67
        echo "        </tbody>
    </table>
</div>
";
    }

    public function getTemplateName()
    {
        return "_components/utilities/SystemReport";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  201 => 67,  187 => 64,  184 => 63,  178 => 61,  172 => 59,  170 => 58,  165 => 57,  163 => 56,  159 => 54,  155 => 53,  148 => 49,  145 => 48,  139 => 46,  134 => 43,  125 => 40,  121 => 39,  118 => 38,  114 => 37,  110 => 35,  108 => 34,  103 => 32,  100 => 31,  94 => 29,  89 => 26,  80 => 23,  76 => 22,  73 => 21,  69 => 20,  65 => 18,  63 => 17,  58 => 15,  53 => 12,  44 => 9,  40 => 8,  37 => 7,  33 => 6,  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_components/utilities/SystemReport", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/_components/utilities/SystemReport.html");
    }
}
