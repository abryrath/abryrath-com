<?php

/* _partials/nav-menu/internalLink */
class __TwigTemplate_014ef193269d64dbb3f31a2844f60ee14ec35970e8741c4446c268333403fd16 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<li class=\"Menu-item\">
    <a href=\"";
        // line 2
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["link"] ?? null), "page", array()), "one", array()), "url", array()), "html", null, true);
        echo "\">
        ";
        // line 3
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["link"] ?? null), "displayText", array()), "html", null, true);
        echo "
    </a>
</li>";
    }

    public function getTemplateName()
    {
        return "_partials/nav-menu/internalLink";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_partials/nav-menu/internalLink", "/home/abry/Sites/caitlinandabry-com/templates/_partials/nav-menu/internalLink.twig");
    }
}
