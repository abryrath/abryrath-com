<?php

/* _includes/forms/text */
class __TwigTemplate_0e1fb1c1636d4ce77430b1d90cefeddcec4a4066aabccea105f919f71d78fba0 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["type"] = (((isset($context["type"]) || array_key_exists("type", $context))) ? (($context["type"] ?? null)) : ("text"));
        // line 2
        $context["autocomplete"] = (((isset($context["autocomplete"]) || array_key_exists("autocomplete", $context))) ? (($context["autocomplete"] ?? null)) : (false));
        // line 4
        $context["class"] = twig_join_filter(array_filter(array(0 => "text", 1 => (((        // line 6
(isset($context["class"]) || array_key_exists("class", $context)) && ($context["class"] ?? null))) ? (($context["class"] ?? null)) : (null)), 2 => (((        // line 7
($context["type"] ?? null) == "password")) ? ("password") : (null)), 3 => (((        // line 8
(isset($context["disabled"]) || array_key_exists("disabled", $context)) && ($context["disabled"] ?? null))) ? ("disabled") : (null)), 4 => (((        // line 9
(isset($context["size"]) || array_key_exists("size", $context)) && ($context["size"] ?? null))) ? (null) : ("fullwidth")))), " ");
        // line 12
        if (((((isset($context["showCharsLeft"]) || array_key_exists("showCharsLeft", $context)) && ($context["showCharsLeft"] ?? null)) && (isset($context["maxlength"]) || array_key_exists("maxlength", $context))) && ($context["maxlength"] ?? null))) {
            // line 13
            $context["style"] = (((("padding-" . (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "locale", array()), "getOrientation", array(), "method") == "ltr")) ? ("right") : ("left"))) . ": ") . ((7.2 * twig_length_filter($this->env, ($context["maxlength"] ?? null))) + 14)) . "px;");
        }
        // line 16
        if ((($context["type"] ?? null) == "password")) {
            echo "<div class=\"passwordwrapper\">";
        }
        // line 17
        echo "<input class=\"";
        echo twig_escape_filter($this->env, ($context["class"] ?? null), "html", null, true);
        echo "\" type=\"";
        echo twig_escape_filter($this->env, ($context["type"] ?? null), "html", null, true);
        echo "\"";
        // line 18
        if ((isset($context["style"]) || array_key_exists("style", $context))) {
            echo " style=\"";
            echo twig_escape_filter($this->env, ($context["style"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 19
        if ((isset($context["id"]) || array_key_exists("id", $context))) {
            echo " id=\"";
            echo twig_escape_filter($this->env, ($context["id"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 20
        if ((isset($context["size"]) || array_key_exists("size", $context))) {
            echo " size=\"";
            echo twig_escape_filter($this->env, ($context["size"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 21
        if ((isset($context["name"]) || array_key_exists("name", $context))) {
            echo " name=\"";
            echo twig_escape_filter($this->env, ($context["name"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 22
        if ((isset($context["value"]) || array_key_exists("value", $context))) {
            echo " value=\"";
            echo twig_escape_filter($this->env, ($context["value"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 23
        if (((isset($context["maxlength"]) || array_key_exists("maxlength", $context)) && ($context["maxlength"] ?? null))) {
            echo " maxlength=\"";
            echo twig_escape_filter($this->env, ($context["maxlength"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 24
        if (((isset($context["showCharsLeft"]) || array_key_exists("showCharsLeft", $context)) && ($context["showCharsLeft"] ?? null))) {
            echo " data-show-chars-left";
        }
        // line 25
        if ((((isset($context["autofocus"]) || array_key_exists("autofocus", $context)) && ($context["autofocus"] ?? null)) &&  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "isMobileBrowser", array(0 => true), "method"))) {
            echo " autofocus";
        }
        // line 26
        if ( !(($context["autocomplete"] ?? null) === null)) {
            echo " autocomplete=\"";
            echo twig_escape_filter($this->env, (((($context["autocomplete"] ?? null) === true)) ? ("on") : (((($context["autocomplete"] ?? null)) ? (($context["autocomplete"] ?? null)) : ("off")))), "html", null, true);
            echo "\"";
        }
        // line 27
        if (((isset($context["disabled"]) || array_key_exists("disabled", $context)) && ($context["disabled"] ?? null))) {
            echo " disabled ";
        }
        // line 28
        if (((isset($context["readonly"]) || array_key_exists("readonly", $context)) && ($context["readonly"] ?? null))) {
            echo " readonly ";
        }
        // line 29
        if ((isset($context["title"]) || array_key_exists("title", $context))) {
            echo " title=\"";
            echo twig_escape_filter($this->env, ($context["title"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 30
        if ((isset($context["placeholder"]) || array_key_exists("placeholder", $context))) {
            echo " placeholder=\"";
            echo twig_escape_filter($this->env, ($context["placeholder"] ?? null), "html", null, true);
            echo "\"";
        }
        // line 31
        if (        $this->hasBlock("attr", $context, $blocks)) {
            echo " ";
            $this->displayBlock("attr", $context, $blocks);
        }
        echo ">";
        // line 32
        if ((($context["type"] ?? null) == "password")) {
            echo "</div>";
        }
    }

    public function getTemplateName()
    {
        return "_includes/forms/text";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 32,  118 => 31,  112 => 30,  106 => 29,  102 => 28,  98 => 27,  92 => 26,  88 => 25,  84 => 24,  78 => 23,  72 => 22,  66 => 21,  60 => 20,  54 => 19,  48 => 18,  42 => 17,  38 => 16,  35 => 13,  33 => 12,  31 => 9,  30 => 8,  29 => 7,  28 => 6,  27 => 4,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_includes/forms/text", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/_includes/forms/text.html");
    }
}
