<?php

/* _partials/menu.twig */
class __TwigTemplate_22b72e78486f191b7e008a3e6807c00afda91a20fafab7cd4936a3ec5f185d15 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<nav role=\"navigation\">
    <div class=\"Menu-mobile-hamburger\">&#9776;</div>
    <div class=\"Menu\">
        <ul>
            ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["navMenu"] ?? null), "navMenu", array()), "all", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
            // line 6
            echo "                ";
            $this->loadTemplate(("_partials/nav-menu/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["link"], "type", array()), "handle", array())), "_partials/menu.twig", 6)->display(array("link" =>             // line 7
$context["link"]));
            // line 9
            echo "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['link'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 10
        echo "        </ul>
    </div>
</nav>
";
    }

    public function getTemplateName()
    {
        return "_partials/menu.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 10,  37 => 9,  35 => 7,  33 => 6,  29 => 5,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_partials/menu.twig", "/home/abry/Sites/caitlinandabry-com/templates/_partials/menu.twig");
    }
}
