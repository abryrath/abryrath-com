<?php

/* _components/widgets/Feed/settings */
class __TwigTemplate_33d588559f9fb791f6b74ae7af7b25e29fc561e84d8186c975102aea9ea7aa1d extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "_components/widgets/Feed/settings", 1);
        // line 2
        echo "

";
        // line 4
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("URL", "app"), "id" => "url", "name" => "url", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 8
($context["widget"] ?? null), "url", array()), "required" => true, "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 10
($context["widget"] ?? null), "getErrors", array(0 => "url"), "method")));
        // line 11
        echo "


";
        // line 14
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title", "app"), "id" => "title", "name" => "title", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 18
($context["widget"] ?? null), "title", array()), "required" => true, "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 20
($context["widget"] ?? null), "getErrors", array(0 => "title"), "method")));
        // line 21
        echo "


";
        // line 24
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Limit", "app"), "id" => "limit", "name" => "limit", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 28
($context["widget"] ?? null), "limit", array()), "size" => 2, "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 30
($context["widget"] ?? null), "getErrors", array(0 => "limit"), "method")));
        // line 31
        echo "
";
    }

    public function getTemplateName()
    {
        return "_components/widgets/Feed/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 31,  49 => 30,  48 => 28,  47 => 24,  42 => 21,  40 => 20,  39 => 18,  38 => 14,  33 => 11,  31 => 10,  30 => 8,  29 => 4,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_components/widgets/Feed/settings", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/_components/widgets/Feed/settings.html");
    }
}
