<?php

/* _layouts/message */
class __TwigTemplate_a36f14eff4ccfca9781378f5a8dfbea7ecd0c9ece81e83409c3d52b71b42d558 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/base", "_layouts/message", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'message' => array($this, 'block_message'),
            'foot' => array($this, 'block_foot'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/base";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["bodyClass"] = "message";
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        // line 5
        echo "    <div class=\"message-container\">
        <div id=\"message\" class=\"pane\">
            ";
        // line 7
        $this->displayBlock('message', $context, $blocks);
        // line 8
        echo "        </div>
    </div>
";
    }

    // line 7
    public function block_message($context, array $blocks = array())
    {
    }

    // line 12
    public function block_foot($context, array $blocks = array())
    {
        // line 13
        echo "    <script type=\"text/javascript\">
        var message = document.getElementById('message'),
            margin = -Math.round(message.offsetHeight / 2);
        message.setAttribute('style', 'margin-top: '+margin+'px !important;');
    </script>
";
    }

    public function getTemplateName()
    {
        return "_layouts/message";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  57 => 12,  52 => 7,  46 => 8,  44 => 7,  40 => 5,  37 => 4,  33 => 1,  31 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_layouts/message", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/_layouts/message.html");
    }
}
