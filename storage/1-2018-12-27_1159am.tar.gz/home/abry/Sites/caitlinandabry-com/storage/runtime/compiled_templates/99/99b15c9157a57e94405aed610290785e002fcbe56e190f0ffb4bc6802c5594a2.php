<?php

/* _layouts/basecp */
class __TwigTemplate_b066b91aa260ec0d87e5dbdbcf8fe5a4992a403f7a2b2a823eb4cf228cb1d8f6 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/base", "_layouts/basecp", 1);
        $this->blocks = array(
            'foot' => array($this, 'block_foot'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/base";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 4
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "isMobileBrowser", array(0 => true), "method")) {
            // line 5
            $context["bodyClass"] = (((((isset($context["bodyClass"]) || array_key_exists("bodyClass", $context)) && ($context["bodyClass"] ?? null))) ? ((($context["bodyClass"] ?? null) . " ")) : ("")) . "mobile");
        }
        // line 8
        craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["view"] ?? null), "registerTranslations", array(0 => "app", 1 => array(0 => "Show", 1 => "Hide")), "method");
        // line 13
        $context["localeData"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "locale", array());
        // line 14
        $context["orientation"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["localeData"] ?? null), "getOrientation", array(), "method");
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 16
    public function block_foot($context, array $blocks = array())
    {
        // line 17
        echo "    <form id=\"x\" method=\"post\" accept-charset=\"UTF-8\">
        ";
        // line 18
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->csrfInputFunction(), "html", null, true);
        echo "
    </form>
    <noscript>
        <div class=\"message-container no-access\">
            <div class=\"pane notice\">
                <p>";
        // line 23
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("JavaScript must be enabled to access the Craft control panel.", "app"), "html", null, true);
        echo "</p>
            </div>
        </div>
    </noscript>

    ";
        // line 28
        ob_start();
        // line 29
        echo "        // Picture element HTML5 shiv
        document.createElement('picture');
    ";
        Craft::$app->getView()->registerJs(ob_get_clean(), 1);
    }

    public function getTemplateName()
    {
        return "_layouts/basecp";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 29,  66 => 28,  58 => 23,  50 => 18,  47 => 17,  44 => 16,  40 => 1,  38 => 14,  36 => 13,  34 => 8,  31 => 5,  29 => 4,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_layouts/basecp", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/_layouts/basecp.html");
    }
}
