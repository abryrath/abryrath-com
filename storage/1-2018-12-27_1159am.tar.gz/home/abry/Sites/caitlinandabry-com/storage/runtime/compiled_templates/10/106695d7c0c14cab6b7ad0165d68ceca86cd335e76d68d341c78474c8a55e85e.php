<?php

/* login */
class __TwigTemplate_b5f3478dfe902f66185655c8ce7e7524dbe0372219f6ba75d9aa432646b64620 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/basecp", "login", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/basecp";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["forms"] = $this->loadTemplate("_includes/forms", "login", 2);
        // line 3
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Login", "app");
        // line 4
        $context["bodyClass"] = "login";
        // line 5
        craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["view"] ?? null), "registerAssetBundle", array(0 => "craft\\web\\assets\\login\\LoginAsset"), "method");
        // line 6
        craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["view"] ?? null), "registerTranslations", array(0 => "app", 1 => array(0 => "Reset Password", 1 => "Check your email for instructions to reset your password.")), "method");
        // line 11
        $context["username"] = ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "config", array()), "general", array()), "rememberUsernameDuration", array())) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "user", array()), "getRememberedUsername", array(), "method")) : (""));
        // line 13
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "config", array()), "general", array()), "useEmailAsUsername", array())) {
            // line 14
            $context["usernamePlaceholder"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Email", "app");
            // line 15
            $context["usernameType"] = "email";
        } else {
            // line 17
            $context["usernamePlaceholder"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Username or Email", "app");
            // line 18
            $context["usernameType"] = "text";
        }
        // line 21
        $context["cpAssetUrl"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["view"] ?? null), "getAssetManager", array(), "method"), "getPublishedUrl", array(0 => "@app/web/assets/cp/dist", 1 => true), "method");
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 23
    public function block_body($context, array $blocks = array())
    {
        // line 24
        echo "    <script type=\"text/javascript\">
        var cookieTest = 'CraftCookieTest='+Math.floor(Math.random() * 1000000);
        document.cookie = cookieTest;
        var cookiesEnabled = document.cookie.search(cookieTest) != -1;
        if (cookiesEnabled)
        {
            document.cookie = cookieTest + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';

            document.write(
                    '";
        // line 33
        $context["hasLogo"] = ((((($context["CraftEdition"] ?? null) == ($context["CraftPro"] ?? null)) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "rebrand", array()), "isLogoUploaded", array()))) ? (true) : (false));
        echo "'+
                    '<form id=\"login-form\" method=\"post\" accept-charset=\"UTF-8\" ";
        // line 34
        if (($context["hasLogo"] ?? null)) {
            // line 35
            $context["logo"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "rebrand", array()), "logo", array());
            // line 36
            $context["padding"] = (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["logo"] ?? null), "height", array()) + 30);
            // line 37
            echo "class=\"has-logo\" style=\"background-image: url(\\'";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["logo"] ?? null), "url", array()), "html", null, true);
            echo "\\'); background-size: ";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["logo"] ?? null), "width", array()), "html", null, true);
            echo "px ";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["logo"] ?? null), "height", array()), "html", null, true);
            echo "px; padding-top: ";
            echo twig_escape_filter($this->env, ($context["padding"] ?? null), "html", null, true);
            echo "px; margin-top: -";
            echo twig_escape_filter($this->env, twig_round(((353 + ($context["padding"] ?? null)) / 2)), "html", null, true);
            echo "px\"";
        }
        // line 38
        echo ">' +
            '";
        // line 39
        if ( !($context["hasLogo"] ?? null)) {
            echo "<h1>";
            echo twig_escape_filter($this->env, ($context["systemName"] ?? null), "html", null, true);
            echo "</h1>";
        }
        echo "'+
            \"";
        // line 40
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $context["forms"]->macro_textField(array("id" => "loginName", "name" => "username", "placeholder" => ($context["usernamePlaceholder"] ?? null), "value" => ($context["username"] ?? null), "autocomplete" => "username", "type" => ($context["usernameType"] ?? null))), "js"), "html", null, true);
        echo "\" +

            '<div id=\"login-fields\" class=\"nested-fields\">' +
            \"";
        // line 43
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $context["forms"]->macro_passwordField(array("id" => "password", "name" => "password", "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Password", "app"), "autocomplete" => "current-password")), "js"), "html", null, true);
        echo "\" +
            '<a id=\"forgot-password\">";
        // line 44
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Forgot your password?", "app"), "html", null, true);
        echo "</a>' +
            ";
        // line 45
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "config", array()), "general", array()), "rememberedUserSessionDuration", array())) {
            // line 46
            echo "            '";
            echo twig_escape_filter($this->env, twig_escape_filter($this->env, $context["forms"]->macro_checkboxField(array("id" => "rememberMe", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Keep me logged in", "app"))), "js"), "html", null, true);
            echo "' +
            ";
        }
        // line 48
        echo "            '</div>' +

            '<div class=\"buttons\">' +
            '";
        // line 51
        echo "' +
            '<input id=\"submit\" class=\"btn submit disabled\" type=\"submit\" value=\"";
        // line 52
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Login", "app"), "html", null, true);
        echo "\">' +
            '<div id=\"spinner\" class=\"spinner hidden\"></div>' +
            '</div>' +
            '<a id=\"poweredby\" href=\"http://craftcms.com/\" title=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Powered by Craft CMS", "app"), "html", null, true);
        echo "\"><img src=\"";
        echo twig_escape_filter($this->env, ($context["cpAssetUrl"] ?? null), "html", null, true);
        echo "/images/craftcms.svg\" /></a>'+
            '</form>'
        );

            ";
        // line 59
        if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "isMobileBrowser", array(0 => true), "method")) {
            // line 60
            echo "            document.getElementById(\"";
            echo ((($context["username"] ?? null)) ? ("password") : ("loginName"));
            echo "\").focus();
            ";
        }
        // line 62
        echo "        }
        else
        {
            document.write(
                '<div class=\"no-access\">' +
                    '<div class=\"pane\">' +
                        '<div class=\"pane-body\">' +
                            '<div class=\"notice\">' +
                                '<div class=\"icon\"></div>' +
                                '<p>";
        // line 71
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Cookies must be enabled to access the Craft CMS control panel.", "app"), "html", null, true);
        echo "<br>' +
                                    '<a class=\"go nowrap\" href=\"\">";
        // line 72
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("See how", "app"), "html", null, true);
        echo "</a>' +
                                '</p>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>'
            );
        }
    </script>
";
    }

    public function getTemplateName()
    {
        return "login";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  175 => 72,  171 => 71,  160 => 62,  154 => 60,  152 => 59,  143 => 55,  137 => 52,  134 => 51,  129 => 48,  123 => 46,  121 => 45,  117 => 44,  113 => 43,  107 => 40,  99 => 39,  96 => 38,  83 => 37,  81 => 36,  79 => 35,  77 => 34,  73 => 33,  62 => 24,  59 => 23,  55 => 1,  53 => 21,  50 => 18,  48 => 17,  45 => 15,  43 => 14,  41 => 13,  39 => 11,  37 => 6,  35 => 5,  33 => 4,  31 => 3,  29 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "login", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/login.html");
    }
}
