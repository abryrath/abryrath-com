<?php

/* _partials/accordion */
class __TwigTemplate_7bb8a74bb9061769bbfdae3ac6063435d95f38ad0335b6e10ad3d1b5e3ae6bb7 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"Accordion\" data-accordion>
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["children"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 3
            echo "        <div class=\"Accordion-child\" data-accordion-child=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["child"], "id", array()), "html", null, true);
            echo "\">
            <div class=\"Accordion-child--title\" data-accordion-child-title=\"";
            // line 4
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["child"], "id", array()), "html", null, true);
            echo "\">
                <span>";
            // line 5
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["child"], "travelTitle", array()), "html", null, true);
            echo "</span>
            </div>
            <div class=\"Accordion-child--body\" data-accordion-child-body=\"";
            // line 7
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["child"], "id", array()), "html", null, true);
            echo "\">
                ";
            // line 8
            echo $this->extensions['craft\web\twig\Extension']->replaceFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["child"], "body", array()), array("<p>" => "<p class=\"Wysiwyg-copy\">", "<ul>" => "<ul class=\"Wysiwyg-list\">"));
            // line 11
            echo "
            </div>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "</div>";
    }

    public function getTemplateName()
    {
        return "_partials/accordion";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 15,  50 => 11,  48 => 8,  44 => 7,  39 => 5,  35 => 4,  30 => 3,  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_partials/accordion", "/home/abry/Sites/caitlinandabry-com/templates/_partials/accordion.twig");
    }
}
