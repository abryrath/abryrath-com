<?php

/* things-to-do/explore */
class __TwigTemplate_6d9fd71b8737d8ae64a0a3f6a77f020cb9f302914de190c7280a626aad458914 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 2
        return $this->loadTemplate(((($context["isAjax"] ?? null)) ? ("_layouts/ajax") : ("_layouts/default")), "things-to-do/explore", 2);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["isAjax"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "isAjax", array());
        // line 4
        $context["costFilter"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "getParam", array(0 => "cost"), "method");
        // line 5
        $context["areasFilter"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "getParam", array(0 => "areas"), "method");
        // line 6
        $context["attractionQuery"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "get", array(0 => "attractions"), "method"), "filter", array(0 => array("cost" =>         // line 7
($context["costFilter"] ?? null), "areas" =>         // line 8
($context["areasFilter"] ?? null), "orderBy" => "title asc")), "method");
        // line 12
        $context["costs"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "entries", array()), "section", array(0 => "costs"), "method"), "orderBy", array(0 => "title desc"), "method"), "all", array());
        // line 13
        $context["areas"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "entries", array()), "section", array(0 => "areas"), "method"), "orderBy", array(0 => "title asc"), "method"), "all", array());
        // line 14
        list($context["pageInfo"], $context["attractions"]) = \craft\helpers\Template::paginateCriteria(($context["attractionQuery"] ?? null));
        // line 2
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 16
    public function block_content($context, array $blocks = array())
    {
        // line 17
        echo "    ";
        if (($context["isAjax"] ?? null)) {
            // line 18
            echo "        ";
            $context["showPlaces"] = array();
            // line 19
            echo "        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["restaurantQuery"] ?? null), "all", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["place"]) {
                // line 20
                echo "            ";
                if ( !twig_test_empty(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["place"], "location", array()))) {
                    // line 21
                    echo "                ";
                    $context["showPlaces"] = twig_array_merge(($context["showPlaces"] ?? null), array(0 => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["place"], "location", array())));
                    // line 22
                    echo "            ";
                }
                // line 23
                echo "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['place'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 24
            echo "        ";
            echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(($context["showPlaces"] ?? null));
            echo "
    ";
        } else {
            // line 26
            echo "        ";
            $this->loadTemplate("_partials/wysiwyg", "things-to-do/explore", 26)->display(array("content" => array("sectionHeading" => "Explore", "copy" => "")));
            // line 32
            echo "        
        ";
            // line 33
            $this->loadTemplate("things-to-do/listingFilter", "things-to-do/explore", 33)->display(array("type" => "things-to-do/explore", "costs" =>             // line 35
($context["costs"] ?? null), "areas" =>             // line 36
($context["areas"] ?? null)));
            // line 38
            echo "
        ";
            // line 39
            $this->loadTemplate("_partials/map", "things-to-do/explore", 39)->display(array("places" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 40
($context["attractionQuery"] ?? null), "all", array(), "method")));
            // line 42
            echo "    ";
        }
    }

    public function getTemplateName()
    {
        return "things-to-do/explore";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 42,  97 => 40,  96 => 39,  93 => 38,  91 => 36,  90 => 35,  89 => 33,  86 => 32,  83 => 26,  77 => 24,  71 => 23,  68 => 22,  65 => 21,  62 => 20,  57 => 19,  54 => 18,  51 => 17,  48 => 16,  44 => 2,  42 => 14,  40 => 13,  38 => 12,  36 => 8,  35 => 7,  34 => 6,  32 => 5,  30 => 4,  28 => 1,  22 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "things-to-do/explore", "/home/abry/Sites/caitlinandabry-com/templates/things-to-do/explore/index.twig");
    }
}
