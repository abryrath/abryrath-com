<?php

/* utilities/_index */
class __TwigTemplate_8f55642b0bd6793f0aaf939ae2b38a6358244a9a706930cf8a05943a8ac370d3 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "utilities/_index", 1);
        $this->blocks = array(
            'sidebar' => array($this, 'block_sidebar'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 3
        $context["title"] = ($context["displayName"] ?? null);
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_sidebar($context, array $blocks = array())
    {
        // line 6
        echo "    <nav>
        <ul>
            ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["utilities"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["utility"]) {
            // line 9
            echo "                ";
            $context["selected"] = (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["utility"], "id", array()) == ($context["id"] ?? null));
            // line 10
            echo "                <li>
                    <a class=\"";
            // line 11
            if (($context["selected"] ?? null)) {
                echo "sel";
            } elseif (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["utility"], "badgeCount", array())) {
                echo "has-badge";
            }
            echo "\" href=\"";
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url(("utilities/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["utility"], "id", array()))), "html", null, true);
            echo "\">
                        <span class=\"icon icon-mask\">";
            // line 12
            echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["utility"], "iconSvg", array());
            echo "</span>
                        <span class=\"label\">";
            // line 13
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["utility"], "displayName", array()), "html", null, true);
            echo "</span>
                        ";
            // line 14
            if (( !($context["selected"] ?? null) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["utility"], "badgeCount", array()))) {
                // line 15
                echo "                            <span class=\"badge\">";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["utility"], "badgeCount", array()), "html", null, true);
                echo "</span>
                        ";
            }
            // line 17
            echo "                    </a>
                </li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['utility'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "        </ul>
    </nav>
";
    }

    // line 24
    public function block_content($context, array $blocks = array())
    {
        // line 25
        echo "    ";
        echo ($context["contentHtml"] ?? null);
        echo "
";
    }

    public function getTemplateName()
    {
        return "utilities/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 25,  93 => 24,  87 => 20,  79 => 17,  73 => 15,  71 => 14,  67 => 13,  63 => 12,  53 => 11,  50 => 10,  47 => 9,  43 => 8,  39 => 6,  36 => 5,  32 => 1,  30 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "utilities/_index", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/utilities/_index.html");
    }
}
