<?php

/* travel-accommodations/_entry */
class __TwigTemplate_52650e4d58388df08ae0dd4b84d5750c71756f24a0c5a2b3695bd83dc3c889ab extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/default", "travel-accommodations/_entry", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/default";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo "    ";
        $cacheService = Craft::$app->getTemplateCaches();
        $request = Craft::$app->getRequest();
        $ignoreCache1 = ($request->getIsLivePreview() || $request->getToken() || ((getenv("APP_ENV") == "development")));
        if (!$ignoreCache1) {
            $cacheKey1 = "WF7aaMNbLSb7HuRyOK1pRVjFKWTk3YKp8pqg";
            $cacheBody1 = $cacheService->getTemplateCache($cacheKey1, true);
        } else {
            $cacheBody1 = null;
        }
        if ($cacheBody1 === null) {
            if (!$ignoreCache1) {
                $cacheService->startTemplateCache($cacheKey1);
            }
            ob_start();
            // line 4
            echo "
        ";
            // line 5
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "accommodationsContent", array()), "all", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["content"]) {
                // line 6
                echo "            ";
                $this->loadTemplate(("_partials/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["content"], "type", array()), "handle", array())), "travel-accommodations/_entry", 6)->display(array("content" =>                 // line 7
$context["content"]));
                // line 9
                echo "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['content'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 10
            echo "            
        ";
            // line 11
            $this->loadTemplate("hotels/accordion", "travel-accommodations/_entry", 11)->display(array("children" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 12
($context["entry"] ?? null), "hotelsList", array()), "all", array())));
            // line 14
            echo "
        ";
            // line 15
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "travelContent", array()), "all", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["content"]) {
                // line 16
                echo "            ";
                $this->loadTemplate(("_partials/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["content"], "type", array()), "handle", array())), "travel-accommodations/_entry", 16)->display(array("content" =>                 // line 17
$context["content"]));
                // line 19
                echo "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['content'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 20
            echo "
        ";
            // line 21
            $this->loadTemplate("_partials/accordion", "travel-accommodations/_entry", 21)->display(array("children" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 22
($context["entry"] ?? null), "travelAccordion", array()), "all", array())));
            // line 24
            echo "    ";
            $cacheBody1 = ob_get_clean();
            if (!$ignoreCache1) {
                $cacheService->endTemplateCache($cacheKey1, true, null, null, $cacheBody1);
            }
        }
        echo $cacheBody1;
    }

    public function getTemplateName()
    {
        return "travel-accommodations/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 24,  95 => 22,  94 => 21,  91 => 20,  85 => 19,  83 => 17,  81 => 16,  77 => 15,  74 => 14,  72 => 12,  71 => 11,  68 => 10,  62 => 9,  60 => 7,  58 => 6,  54 => 5,  51 => 4,  35 => 3,  32 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "travel-accommodations/_entry", "/home/abry/Sites/caitlinandabry-com/templates/travel-accommodations/_entry.twig");
    }
}
