<?php

/* home/_entry */
class __TwigTemplate_8daf87503d9cb5612b4ce1c1ca7d3d7606946ac6458594a1eb6b1a102059be9d extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/default", "home/_entry", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/default";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $cacheService = Craft::$app->getTemplateCaches();
        $request = Craft::$app->getRequest();
        $ignoreCache1 = ($request->getIsLivePreview() || $request->getToken() || ((getenv("APP_ENV") == "development")));
        if (!$ignoreCache1) {
            $cacheKey1 = "nyBtzLsy8D3tEy6DaH96PxBpBc8Gc9FLmgk2";
            $cacheBody1 = $cacheService->getTemplateCache($cacheKey1, true);
        } else {
            $cacheBody1 = null;
        }
        if ($cacheBody1 === null) {
            if (!$ignoreCache1) {
                $cacheService->startTemplateCache($cacheKey1);
            }
            ob_start();
            // line 5
            echo "        ";
            $context["hero"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "pageHeroImage", array());
            // line 6
            echo "        ";
            if (twig_length_filter($this->env, ($context["hero"] ?? null))) {
                // line 7
                echo "            <div class=\"Hero\">
                <img src=\"";
                // line 8
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["hero"] ?? null), "one", array()), "getUrl", array()), "html", null, true);
                echo "\"/>
            </div>
        ";
            }
            // line 11
            echo "
        ";
            // line 12
            $this->loadTemplate("_partials/wysiwyg", "home/_entry", 12)->display(array("content" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 13
($context["entry"] ?? null), "wysiwyg", array())));
            // line 15
            echo "    ";
            $cacheBody1 = ob_get_clean();
            if (!$ignoreCache1) {
                $cacheService->endTemplateCache($cacheKey1, true, null, null, $cacheBody1);
            }
        }
        echo $cacheBody1;
    }

    public function getTemplateName()
    {
        return "home/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 15,  70 => 13,  69 => 12,  66 => 11,  60 => 8,  57 => 7,  54 => 6,  51 => 5,  35 => 4,  32 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "home/_entry", "/home/abry/Sites/caitlinandabry-com/templates/home/_entry.twig");
    }
}
