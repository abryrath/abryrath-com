<?php

/* _partials/address */
class __TwigTemplate_f153cba70d8b3a43688a9c0679b8e2cb40c2c262e72b731a1601dcbaac240fc2 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"Address\">
    <div class=\"Address-content\">
        ";
        // line 3
        echo nl2br(twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["content"] ?? null), "address", array()), "html", null, true));
        echo "
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "_partials/address";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_partials/address", "/home/abry/Sites/caitlinandabry-com/templates/_partials/address.twig");
    }
}
