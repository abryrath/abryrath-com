<?php

/* _includes/forms */
class __TwigTemplate_84edda4d2aa9be8f5084d99da69b48e04a710e9e77441400d3f5cd8559a03bae extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 4
        echo "

";
        // line 7
        echo "

";
        // line 12
        echo "

";
        // line 17
        echo "

";
        // line 22
        echo "

";
        // line 27
        echo "

";
        // line 32
        echo "

";
        // line 37
        echo "

";
        // line 42
        echo "

";
        // line 47
        echo "

";
        // line 52
        echo "

";
        // line 57
        echo "

";
        // line 62
        echo "

";
        // line 67
        echo "

";
        // line 72
        echo "

";
        // line 77
        echo "

";
        // line 82
        echo "

";
        // line 87
        echo "

";
        // line 92
        echo "

";
        // line 97
        echo "

";
        // line 100
        echo "

";
        // line 105
        echo "

";
        // line 121
        echo "

";
        // line 127
        echo "

";
        // line 133
        echo "

";
        // line 139
        echo "

";
        // line 145
        echo "

";
        // line 157
        echo "

";
        // line 163
        echo "

";
        // line 169
        echo "

";
        // line 175
        echo "

";
        // line 195
        echo "

";
        // line 201
        echo "

";
        // line 207
        echo "

";
        // line 213
        echo "

";
        // line 219
        echo "

";
        // line 229
        echo "

";
        // line 236
        echo "

";
        // line 242
        echo "

";
        // line 245
        echo "

";
    }

    // line 1
    public function macro_errorList($__errors__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "errors" => $__errors__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 2
            echo "    ";
            $this->loadTemplate("_includes/forms/errorList", "_includes/forms", 2)->display($context);

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 9
    public function macro_hidden($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 10
            $this->loadTemplate("_includes/forms/hidden", "_includes/forms", 10)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 14
    public function macro_text($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 15
            echo "    ";
            $this->loadTemplate("_includes/forms/text", "_includes/forms", 15)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 19
    public function macro_password($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 20
            echo "    ";
            $this->loadTemplate("_includes/forms/text", "_includes/forms", 20)->display(twig_array_merge(($context["config"] ?? null), array("type" => "password")));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 24
    public function macro_date($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 25
            echo "    ";
            $this->loadTemplate("_includes/forms/date", "_includes/forms", 25)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 29
    public function macro_time($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 30
            echo "    ";
            $this->loadTemplate("_includes/forms/time", "_includes/forms", 30)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 34
    public function macro_color($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 35
            echo "    ";
            $this->loadTemplate("_includes/forms/color", "_includes/forms", 35)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 39
    public function macro_textarea($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 40
            echo "    ";
            $this->loadTemplate("_includes/forms/textarea", "_includes/forms", 40)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 44
    public function macro_select($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 45
            echo "    ";
            $this->loadTemplate("_includes/forms/select", "_includes/forms", 45)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 49
    public function macro_multiselect($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 50
            echo "    ";
            $this->loadTemplate("_includes/forms/multiselect", "_includes/forms", 50)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 54
    public function macro_checkbox($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 55
            echo "    ";
            $this->loadTemplate("_includes/forms/checkbox", "_includes/forms", 55)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 59
    public function macro_checkboxGroup($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 60
            echo "    ";
            $this->loadTemplate("_includes/forms/checkboxGroup", "_includes/forms", 60)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 64
    public function macro_checkboxSelect($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 65
            echo "    ";
            $this->loadTemplate("_includes/forms/checkboxSelect", "_includes/forms", 65)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 69
    public function macro_radio($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 70
            echo "    ";
            $this->loadTemplate("_includes/forms/radio", "_includes/forms", 70)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 74
    public function macro_radioGroup($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 75
            echo "    ";
            $this->loadTemplate("_includes/forms/radioGroup", "_includes/forms", 75)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 79
    public function macro_file($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 80
            echo "    ";
            $this->loadTemplate("_includes/forms/file", "_includes/forms", 80)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 84
    public function macro_lightswitch($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 85
            echo "    ";
            $this->loadTemplate("_includes/forms/lightswitch", "_includes/forms", 85)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 89
    public function macro_editableTable($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 90
            echo "    ";
            $this->loadTemplate("_includes/forms/editableTable", "_includes/forms", 90)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 94
    public function macro_elementSelect($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 95
            echo "    ";
            $this->loadTemplate("_includes/forms/elementSelect", "_includes/forms", 95)->display(($context["config"] ?? null));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 102
    public function macro_field($__config__ = null, $__input__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "input" => $__input__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 103
            echo "    ";
            $this->loadTemplate("_includes/forms/field", "_includes/forms", 103)->display(twig_array_merge(($context["config"] ?? null), array("input" => ($context["input"] ?? null))));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 107
    public function macro_textField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 108
            echo "    ";
            $context["forms"] = $this;
            // line 109
            echo "    ";
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "unit", array(), "any", true, true)) {
                // line 110
                echo "        ";
                ob_start();
                // line 111
                echo "            <div class=\"flex\">
                <div class=\"textwrapper\">";
                // line 112
                echo $context["forms"]->macro_text(($context["config"] ?? null));
                echo "</div>
                <div class=\"label light\">";
                // line 113
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "unit", array()), "html", null, true);
                echo "</div>
            </div>
        ";
                $context["input"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
                // line 116
                echo "    ";
            } else {
                // line 117
                echo "        ";
                $context["input"] = $context["forms"]->macro_text(($context["config"] ?? null));
                // line 118
                echo "    ";
            }
            // line 119
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), ($context["input"] ?? null));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 123
    public function macro_passwordField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 124
            echo "    ";
            $context["forms"] = $this;
            // line 125
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_password(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 129
    public function macro_dateField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 130
            echo "    ";
            $context["forms"] = $this;
            // line 131
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_date(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 135
    public function macro_timeField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 136
            echo "    ";
            $context["forms"] = $this;
            // line 137
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_time(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 141
    public function macro_colorField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 142
            echo "    ";
            $context["forms"] = $this;
            // line 143
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_color(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 147
    public function macro_dateTimeField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 148
            echo "    ";
            $context["forms"] = $this;
            // line 149
            echo "    ";
            ob_start();
            // line 150
            echo "        <div class=\"datetimewrapper\">
            ";
            // line 151
            echo $context["forms"]->macro_date(($context["config"] ?? null));
            echo "
            ";
            // line 152
            echo $context["forms"]->macro_time(($context["config"] ?? null));
            echo "
        </div>
    ";
            $context["input"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
            // line 155
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), ($context["input"] ?? null));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 159
    public function macro_textareaField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 160
            echo "    ";
            $context["forms"] = $this;
            // line 161
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_textarea(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 165
    public function macro_selectField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 166
            echo "    ";
            $context["forms"] = $this;
            // line 167
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_select(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 171
    public function macro_multiselectField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 172
            echo "    ";
            $context["forms"] = $this;
            // line 173
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_multiselect(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 177
    public function macro_checkboxField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 178
            echo "    ";
            $context["forms"] = $this;
            // line 179
            echo "    ";
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "fieldLabel", array(), "any", true, true)) {
                // line 180
                echo "        ";
                echo $context["forms"]->macro_field(twig_array_merge(($context["config"] ?? null), array("label" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "fieldLabel", array()))), $context["forms"]->macro_checkbox(($context["config"] ?? null)));
                echo "
    ";
            } else {
                // line 182
                echo "        ";
                $context["instructions"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "instructions", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "instructions", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "instructions", array())) : (null));
                // line 183
                $context["warning"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "warning", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "warning", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "warning", array())) : (null));
                // line 184
                echo "<div class=\"field checkboxfield";
                if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "first", array(), "any", true, true) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "first", array()))) {
                    echo " first";
                }
                if (($context["instructions"] ?? null)) {
                    echo " has-instructions";
                }
                echo "\"";
                if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "id", array(), "any", true, true) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "id", array()))) {
                    echo " id=\"";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "id", array()), "html", null, true);
                    echo "-field\"";
                }
                echo ">
            ";
                // line 185
                echo $context["forms"]->macro_checkbox(($context["config"] ?? null));
                echo "
            ";
                // line 186
                if (($context["instructions"] ?? null)) {
                    // line 187
                    echo "                <div class=\"instructions\">";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->markdownFilter(($context["instructions"] ?? null)), "html", null, true);
                    echo "</div>
            ";
                }
                // line 189
                echo "            ";
                if (($context["warning"] ?? null)) {
                    // line 190
                    echo "                <p class=\"warning\">";
                    echo twig_escape_filter($this->env, ($context["warning"] ?? null), "html", null, true);
                    echo "</p>
            ";
                }
                // line 192
                echo "        </div>
    ";
            }

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 197
    public function macro_checkboxGroupField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 198
            echo "    ";
            $context["forms"] = $this;
            // line 199
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_checkboxGroup(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 203
    public function macro_checkboxSelectField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 204
            echo "    ";
            $context["forms"] = $this;
            // line 205
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_checkboxSelect(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 209
    public function macro_radioGroupField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 210
            echo "    ";
            $context["forms"] = $this;
            // line 211
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_radioGroup(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 215
    public function macro_fileField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 216
            echo "    ";
            $context["forms"] = $this;
            // line 217
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_file(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 221
    public function macro_lightswitchField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 222
            echo "    ";
            $context["forms"] = $this;
            // line 223
            echo "    ";
            if (( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "labelId", array(), "any", true, true) ||  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "labelId", array()))) {
                // line 224
                echo "        ";
                $context["config"] = twig_array_merge(($context["config"] ?? null), array("labelId" => ("label" . twig_random($this->env))));
                // line 225
                echo "    ";
            }
            // line 226
            echo "    ";
            $context["config"] = twig_array_merge(($context["config"] ?? null), array("fieldClass" => ("lightswitch-field " . (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "fieldClass", array(), "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "fieldClass", array())))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "fieldClass", array())) : ("")))));
            // line 227
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_lightswitch(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 231
    public function macro_editableTableField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 232
            echo "    ";
            $context["forms"] = $this;
            // line 233
            echo "    ";
            ob_start();
            $this->loadTemplate("_includes/forms/editableTable", "_includes/forms", 233)->display(($context["config"] ?? null));
            $context["input"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
            // line 234
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), ($context["input"] ?? null));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 238
    public function macro_elementSelectField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "config" => $__config__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 239
            echo "    ";
            $context["forms"] = $this;
            // line 240
            echo "    ";
            echo $context["forms"]->macro_field(($context["config"] ?? null), $context["forms"]->macro_elementSelect(($context["config"] ?? null)));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 247
    public function macro_optionShortcutLabel($__key__ = null, $__shift__ = null, $__alt__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals(array(
            "key" => $__key__,
            "shift" => $__shift__,
            "alt" => $__alt__,
            "varargs" => $__varargs__,
        ));

        $blocks = array();

        ob_start();
        try {
            // line 248
            ob_start();
            // line 249
            echo "        ";
            switch (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "getClientOs", array(), "method")) {
                case "Mac":
                {
                    // line 251
                    echo "                <span class=\"shortcut\">";
                    echo twig_escape_filter($this->env, (((((($context["alt"] ?? null)) ? ("⌥") : ("")) . ((($context["shift"] ?? null)) ? ("⇧") : (""))) . "⌘") . ($context["key"] ?? null)), "html", null, true);
                    echo "</span>
            ";
                    break;
                }
                default:
                {
                    // line 253
                    echo "                <span class=\"shortcut\">";
                    echo twig_escape_filter($this->env, ((("Ctrl+" . ((($context["alt"] ?? null)) ? ("Alt+") : (""))) . ((($context["shift"] ?? null)) ? ("Shift+") : (""))) . ($context["key"] ?? null)), "html", null, true);
                    echo "</span>
        ";
                }
            }
            // line 255
            echo "    ";
            echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_includes/forms";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1232 => 255,  1225 => 253,  1216 => 251,  1211 => 249,  1209 => 248,  1195 => 247,  1183 => 240,  1180 => 239,  1168 => 238,  1156 => 234,  1151 => 233,  1148 => 232,  1136 => 231,  1124 => 227,  1121 => 226,  1118 => 225,  1115 => 224,  1112 => 223,  1109 => 222,  1097 => 221,  1085 => 217,  1082 => 216,  1070 => 215,  1058 => 211,  1055 => 210,  1043 => 209,  1031 => 205,  1028 => 204,  1016 => 203,  1004 => 199,  1001 => 198,  989 => 197,  978 => 192,  972 => 190,  969 => 189,  963 => 187,  961 => 186,  957 => 185,  941 => 184,  939 => 183,  936 => 182,  930 => 180,  927 => 179,  924 => 178,  912 => 177,  900 => 173,  897 => 172,  885 => 171,  873 => 167,  870 => 166,  858 => 165,  846 => 161,  843 => 160,  831 => 159,  819 => 155,  813 => 152,  809 => 151,  806 => 150,  803 => 149,  800 => 148,  788 => 147,  776 => 143,  773 => 142,  761 => 141,  749 => 137,  746 => 136,  734 => 135,  722 => 131,  719 => 130,  707 => 129,  695 => 125,  692 => 124,  680 => 123,  668 => 119,  665 => 118,  662 => 117,  659 => 116,  653 => 113,  649 => 112,  646 => 111,  643 => 110,  640 => 109,  637 => 108,  625 => 107,  615 => 103,  602 => 102,  592 => 95,  580 => 94,  570 => 90,  558 => 89,  548 => 85,  536 => 84,  526 => 80,  514 => 79,  504 => 75,  492 => 74,  482 => 70,  470 => 69,  460 => 65,  448 => 64,  438 => 60,  426 => 59,  416 => 55,  404 => 54,  394 => 50,  382 => 49,  372 => 45,  360 => 44,  350 => 40,  338 => 39,  328 => 35,  316 => 34,  306 => 30,  294 => 29,  284 => 25,  272 => 24,  262 => 20,  250 => 19,  240 => 15,  228 => 14,  219 => 10,  207 => 9,  197 => 2,  185 => 1,  179 => 245,  175 => 242,  171 => 236,  167 => 229,  163 => 219,  159 => 213,  155 => 207,  151 => 201,  147 => 195,  143 => 175,  139 => 169,  135 => 163,  131 => 157,  127 => 145,  123 => 139,  119 => 133,  115 => 127,  111 => 121,  107 => 105,  103 => 100,  99 => 97,  95 => 92,  91 => 87,  87 => 82,  83 => 77,  79 => 72,  75 => 67,  71 => 62,  67 => 57,  63 => 52,  59 => 47,  55 => 42,  51 => 37,  47 => 32,  43 => 27,  39 => 22,  35 => 17,  31 => 12,  27 => 7,  23 => 4,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_includes/forms", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/_includes/forms.html");
    }
}
