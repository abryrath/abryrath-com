<?php

/* our-story/_entry */
class __TwigTemplate_b0066f2051a1af41a443cc8ab5553c23dbb317d603d5940ee7afcb3ece908e2b extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/default", "our-story/_entry", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/default";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo "    ";
        // line 4
        echo "        ";
        $context["hero"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "pageHeroImage", array());
        // line 5
        echo "        ";
        if (twig_length_filter($this->env, ($context["hero"] ?? null))) {
            // line 6
            echo "            <div class=\"Hero\">
                <img src=\"";
            // line 7
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["hero"] ?? null), "one", array()), "getUrl", array()), "html", null, true);
            echo "\"/>
            </div>
        ";
        }
        // line 10
        echo "
        ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "ourStoryContent", array()), "all", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["content"]) {
            // line 12
            echo "            ";
            $this->loadTemplate(("_partials/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["content"], "type", array()), "handle", array())), "our-story/_entry", 12)->display(array("content" =>             // line 13
$context["content"]));
            // line 15
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['content'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "    ";
    }

    public function getTemplateName()
    {
        return "our-story/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 16,  63 => 15,  61 => 13,  59 => 12,  55 => 11,  52 => 10,  46 => 7,  43 => 6,  40 => 5,  37 => 4,  35 => 3,  32 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "our-story/_entry", "/home/abry/Sites/caitlinandabry-com/templates/our-story/_entry.twig");
    }
}
