<?php

/* _partials/map */
class __TwigTemplate_ea38a66f312dd0dba2a8015d1dc91fe3737e6a752a721f31876ad2ec4d25cdd6 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"Map\">
    ";
        // line 2
        $context["showPlaces"] = array();
        // line 3
        echo "    ";
        // line 4
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["places"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["place"]) {
            // line 5
            echo "        ";
            if ( !twig_test_empty(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["place"], "location", array()))) {
                // line 6
                echo "            ";
                $context["showPlaces"] = twig_array_merge(($context["showPlaces"] ?? null), array(0 => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["place"], "location", array())));
                // line 7
                echo "        ";
            }
            // line 8
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['place'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 9
        echo "    <div class=\"Map-data\" data-map=\"data-map\" data-map-places=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(($context["showPlaces"] ?? null)), "html", null, true);
        echo "\"></div>
</div>";
    }

    public function getTemplateName()
    {
        return "_partials/map";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 9,  44 => 8,  41 => 7,  38 => 6,  35 => 5,  30 => 4,  28 => 3,  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_partials/map", "/home/abry/Sites/caitlinandabry-com/templates/_partials/map.twig");
    }
}
