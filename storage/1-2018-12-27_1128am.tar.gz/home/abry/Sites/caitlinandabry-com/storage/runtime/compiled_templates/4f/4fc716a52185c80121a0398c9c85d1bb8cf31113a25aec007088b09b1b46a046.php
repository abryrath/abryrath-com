<?php

/* _partials/header */
class __TwigTemplate_8ab10b4ec80933207ea9b605cf4fa01990d8c3d7ba2c55b5ae10d59abca44d74 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "    <section id=\"header\" name=\"header\">
        <div class=\"Header\">
            <div class=\"Header-title\">Caitlin & Abry</div>
            ";
        // line 5
        $this->loadTemplate("_partials/menu.twig", "_partials/header", 5)->display($context);
        // line 6
        echo "        </div>
    </section>
";
    }

    public function getTemplateName()
    {
        return "_partials/header";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 6,  28 => 5,  23 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_partials/header", "/home/abry/Sites/caitlinandabry-com/templates/_partials/header.twig");
    }
}
