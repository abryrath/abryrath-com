<?php

/* _layouts/default */
class __TwigTemplate_667d39d0a95d47f6c59dc2280de8c7e7988831244b3d664a6a6985a583acdcff extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en-US\">
    ";
        // line 3
        $cacheService = Craft::$app->getTemplateCaches();
        $request = Craft::$app->getRequest();
        $ignoreCache2 = ($request->getIsLivePreview() || $request->getToken() || ((getenv("APP_ENV") == "development")));
        if (!$ignoreCache2) {
            $cacheKey2 = "j6dEWeLr4oTw5gezYpYMWUcrZTlE4IXADdOl";
            $cacheBody2 = $cacheService->getTemplateCache($cacheKey2, true);
        } else {
            $cacheBody2 = null;
        }
        if ($cacheBody2 === null) {
            if (!$ignoreCache2) {
                $cacheService->startTemplateCache($cacheKey2);
            }
            ob_start();
            // line 4
            echo "        <head>
            <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />
            <meta charset=\"utf-8\" />
            
            <title>";
            // line 8
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["entry"] ?? null), "title", array()), "html", null, true);
            echo "</title>
            <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover\" />
            <meta name=\"referrer\" content=\"origin-when-cross-origin\" />
            ";
            // line 11
            if ((getenv("APP_ENV") != "development")) {
                // line 12
                echo "                <link rel=\"stylesheet\" type=\"text/css\" href=\"/main.css\" />
            ";
            }
            // line 14
            echo "        ";
            call_user_func_array($this->env->getFunction('head')->getCallable(), array());
            echo "</head>
    ";
            $cacheBody2 = ob_get_clean();
            if (!$ignoreCache2) {
                $cacheService->endTemplateCache($cacheKey2, true, null, null, $cacheBody2);
            }
        }
        echo $cacheBody2;
        // line 16
        echo "    <body>";
        call_user_func_array($this->env->getFunction('beginBody')->getCallable(), array());
        echo "
        <div class=\"body\">
            ";
        // line 18
        $this->loadTemplate("_partials/header", "_layouts/default", 18)->display($context);
        // line 19
        echo "                        
            <section id=\"content\" name=\"content\">
                ";
        // line 21
        $this->displayBlock("content", $context, $blocks);
        echo "
            </section>
            ";
        // line 23
        $cacheService = Craft::$app->getTemplateCaches();
        $request = Craft::$app->getRequest();
        $ignoreCache3 = ($request->getIsLivePreview() || $request->getToken() || ((getenv("APP_ENV") == "development")));
        if (!$ignoreCache3) {
            $cacheKey3 = "DMKcQds5gFQDGZ642JxDXgT4aYBbHZWnt6a3";
            $cacheBody3 = $cacheService->getTemplateCache($cacheKey3, true);
        } else {
            $cacheBody3 = null;
        }
        if ($cacheBody3 === null) {
            if (!$ignoreCache3) {
                $cacheService->startTemplateCache($cacheKey3);
            }
            ob_start();
            // line 24
            echo "                <section id=\"footer\" name=\"footer\">
                    ";
            // line 25
            if ((getenv("APP_ENV") == "development")) {
                // line 26
                echo "                        <script src=\"http://localhost:8080/main.js\"></script>
                    ";
            } else {
                // line 28
                echo "                        <script src=\"/main.js\"></script>
                    ";
            }
            // line 30
            echo "                </section>
            ";
            $cacheBody3 = ob_get_clean();
            if (!$ignoreCache3) {
                $cacheService->endTemplateCache($cacheKey3, true, null, null, $cacheBody3);
            }
        }
        echo $cacheBody3;
        // line 32
        echo "        </div>
    ";
        // line 33
        call_user_func_array($this->env->getFunction('endBody')->getCallable(), array());
        echo "</body>
</html>

";
    }

    public function getTemplateName()
    {
        return "_layouts/default";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 33,  125 => 32,  116 => 30,  112 => 28,  108 => 26,  106 => 25,  103 => 24,  88 => 23,  83 => 21,  79 => 19,  77 => 18,  71 => 16,  60 => 14,  56 => 12,  54 => 11,  48 => 8,  42 => 4,  27 => 3,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_layouts/default", "/home/abry/Sites/caitlinandabry-com/templates/_layouts/default.twig");
    }
}
