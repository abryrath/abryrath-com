<?php

/* _components/widgets/RecentEntries/settings */
class __TwigTemplate_a6b148808dcccc8931f57aa65ad5dff7fcc62cc5af756dc03e5d1a310fbc6ab9 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "_components/widgets/RecentEntries/settings", 1);
        // line 2
        echo "

";
        // line 4
        ob_start();
        // line 5
        echo "    <div class=\"select\">
        <select id=\"section\" name=\"section\">
            <option value=\"*\">";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All", "app"), "html", null, true);
        echo "</option>
            ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "sections", array()), "getAllSections", array(), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["section"]) {
            // line 9
            echo "                ";
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["section"], "type", array()) != "single")) {
                // line 10
                echo "                    <option value=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["section"], "id", array()), "html", null, true);
                echo "\"";
                if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["section"], "id", array()) == craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["widget"] ?? null), "section", array()))) {
                    echo " selected";
                }
                echo ">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["section"], "name", array()), "site"), "html", null, true);
                echo "</option>
                ";
            }
            // line 12
            echo "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['section'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "        </select>
    </div>
";
        $context["sectionInput"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 16
        echo "
";
        // line 17
        echo $context["forms"]->macro_field(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Section", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which section do you want to pull recent entries from?", "app"), "id" => "section"),         // line 21
($context["sectionInput"] ?? null));
        echo "

";
        // line 23
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "getIsMultiSite", array(), "method")) {
            // line 24
            echo "    ";
            $context["editableSites"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "sites", array()), "getEditableSites", array(), "method");
            // line 25
            echo "
    ";
            // line 26
            if ((twig_length_filter($this->env, ($context["editableSites"] ?? null)) > 1)) {
                // line 27
                echo "        ";
                ob_start();
                // line 28
                echo "            <div class=\"select\">
                <select id=\"site-id\" name=\"siteId\">
                    ";
                // line 30
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["editableSites"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["site"]) {
                    // line 31
                    echo "                        <option value=\"";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["site"], "id", array()), "html", null, true);
                    echo "\"";
                    if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["site"], "id", array()) == craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["widget"] ?? null), "siteId", array()))) {
                        echo " selected";
                    }
                    echo ">";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["site"], "name", array()), "site"), "html", null, true);
                    echo "</option>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['site'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 33
                echo "                </select>
            </div>
        ";
                $context["siteInput"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
                // line 36
                echo "
        ";
                // line 37
                echo $context["forms"]->macro_field(array("id" => "site-id", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Site", "app")),                 // line 40
($context["siteInput"] ?? null));
                echo "
    ";
            }
        }
        // line 43
        echo "

";
        // line 45
        echo $context["forms"]->macro_textField(array("label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Limit", "app"), "id" => "limit", "name" => "limit", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 49
($context["widget"] ?? null), "limit", array()), "size" => 2, "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 51
($context["widget"] ?? null), "getErrors", array(0 => "limit"), "method")));
        // line 52
        echo "
";
    }

    public function getTemplateName()
    {
        return "_components/widgets/RecentEntries/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 52,  135 => 51,  134 => 49,  133 => 45,  129 => 43,  123 => 40,  122 => 37,  119 => 36,  114 => 33,  99 => 31,  95 => 30,  91 => 28,  88 => 27,  86 => 26,  83 => 25,  80 => 24,  78 => 23,  73 => 21,  72 => 17,  69 => 16,  64 => 13,  58 => 12,  46 => 10,  43 => 9,  39 => 8,  35 => 7,  31 => 5,  29 => 4,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_components/widgets/RecentEntries/settings", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/_components/widgets/RecentEntries/settings.html");
    }
}
