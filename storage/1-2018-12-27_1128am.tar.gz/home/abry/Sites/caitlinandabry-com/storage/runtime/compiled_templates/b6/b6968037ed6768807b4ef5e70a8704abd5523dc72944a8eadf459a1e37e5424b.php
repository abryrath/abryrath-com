<?php

/* hotels/accordion */
class __TwigTemplate_4515ef33aad4d400a05093a7d688bef3f07dfca29b3ceb4ad3c930c0f74c2054 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"Accordion\" data-accordion=\"data-accordion\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["children"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 3
            echo "        <div class=\"Accordion-child\" data-accordion-child=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["child"], "id", array()), "html", null, true);
            echo "\">
            <div class=\"Accordion-child--title\" data-accordion-child-title=\"";
            // line 4
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["child"], "id", array()), "html", null, true);
            echo "\">
                <span>";
            // line 5
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["child"], "title", array()), "html", null, true);
            echo "</span>
            </div>
            <div class=\"Accordion-child--body\" data-accordion-child-body=\"";
            // line 7
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["child"], "id", array()), "html", null, true);
            echo "\">
                ";
            // line 8
            $this->loadTemplate("hotels/preview", "hotels/accordion", 8)->display(array("hotel" =>             // line 9
$context["child"]));
            // line 11
            echo "            </div>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "</div>";
    }

    public function getTemplateName()
    {
        return "hotels/accordion";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 14,  51 => 11,  49 => 9,  48 => 8,  44 => 7,  39 => 5,  35 => 4,  30 => 3,  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "hotels/accordion", "/home/abry/Sites/caitlinandabry-com/templates/hotels/accordion.twig");
    }
}
