<?php

/* _partials/wysiwyg */
class __TwigTemplate_a0705dc8ef8ddcc7075006f171f3dfa69784b27f242c08d72e811dd65be2c8ab extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"Wysiwyg\">
    ";
        // line 2
        if ( !twig_test_empty(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["content"] ?? null), "sectionHeading", array()))) {
            // line 3
            echo "        <div class=\"Wysiwyg-title\"><span>";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["content"] ?? null), "sectionHeading", array()), "html", null, true);
            echo "</span></div>
    ";
        }
        // line 5
        echo "    ";
        echo $this->extensions['craft\web\twig\Extension']->replaceFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["content"] ?? null), "copy", array()), array("<p>" => "<p class=\"Wysiwyg-copy\">"));
        // line 7
        echo "
</div>";
    }

    public function getTemplateName()
    {
        return "_partials/wysiwyg";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  37 => 7,  34 => 5,  28 => 3,  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "_partials/wysiwyg", "/home/abry/Sites/caitlinandabry-com/templates/_partials/wysiwyg.twig");
    }
}
