<?php

/* hotels/preview */
class __TwigTemplate_667379339cd3bb14fc3d73c998997e1ab2a4d1b1197a3eba8cf5a88bc2fb2d85 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"Hotel\">
    <div class=\"Hotel-image\">
        <img src=\"";
        // line 3
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["hotel"] ?? null), "hotelImage", array()), "one", array()), "getUrl", array(0 => "hotelPreview"), "method"), "html", null, true);
        echo "\">
    </div>
    <div class=\"Hotel-content\">
        <div class=\"Hotel-content--desc\">
            ";
        // line 7
        echo $this->extensions['craft\web\twig\Extension']->replaceFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["hotel"] ?? null), "hotelDescription", array()), array("<p>" => "<p class=\"Wysiwyg-copy\">"));
        // line 9
        echo "
        </div>
        <div class=\"Hotel-content--address\">
            <a target=\"_blank\" href=\"https://www.google.com/maps/dir/?api=1&destination=";
        // line 12
        echo twig_escape_filter($this->env, twig_urlencode_filter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["hotel"] ?? null), "hotelAddress", array())), "html", null, true);
        echo "\">
                ";
        // line 13
        echo nl2br(twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["hotel"] ?? null), "hotelAddress", array()), "html", null, true));
        echo "
            </a>        
        </div>
        <div class=\"Hotel-content--phone\">
            <a href=\"tel:";
        // line 17
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["hotel"] ?? null), "hotelPhone", array()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["hotel"] ?? null), "hotelPhone", array()), "html", null, true);
        echo "</a>
        </div>


        ";
        // line 22
        echo "    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "hotels/preview";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 22,  52 => 17,  45 => 13,  41 => 12,  36 => 9,  34 => 7,  27 => 3,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "hotels/preview", "/home/abry/Sites/caitlinandabry-com/templates/hotels/preview.twig");
    }
}
