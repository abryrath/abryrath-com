<?php

/* registry/card */
class __TwigTemplate_5e512ea63cee926236889bb48824bc8a184706b3cf25f4f0115b2857de505217 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"Registry-card Shadow-desktop\">
    <a href=\"";
        // line 2
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["content"] ?? null), "linkUrl", array()), "html", null, true);
        echo "\" class=\"Registry-card--content\">
        <div class=\"Image\">
            <img src=\"";
        // line 4
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["content"] ?? null), "image", array()), "one", array()), "getUrl", array(0 => "registryCard"), "method"), "html", null, true);
        echo "\">
        </div>
    </a>
</div>";
    }

    public function getTemplateName()
    {
        return "registry/card";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 4,  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "registry/card", "/home/abry/Sites/caitlinandabry-com/templates/registry/card.twig");
    }
}
