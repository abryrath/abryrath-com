<?php

/* things-to-do/drink/index */
class __TwigTemplate_0d78aaf62aa7e0cd7e4b25a288f6f7c17d8104ff51f0806e9c68e4411bb6ec9f extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 2
        return $this->loadTemplate(((($context["isAjax"] ?? null)) ? ("_layouts/ajax") : ("_layouts/default")), "things-to-do/drink/index", 2);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["isAjax"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "isAjax", array());
        // line 4
        $context["areasFilter"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "request", array()), "getParam", array(0 => "areas"), "method");
        // line 5
        $context["barQuery"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "app", array()), "get", array(0 => "bars"), "method"), "filter", array(0 => array("areas" =>         // line 6
($context["areasFilter"] ?? null), "orderBy" => "title asc")), "method");
        // line 10
        $context["areas"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["craft"] ?? null), "entries", array()), "section", array(0 => "areas"), "method"), "orderBy", array(0 => "title asc"), "method"), "all", array());
        // line 2
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 11
    public function block_content($context, array $blocks = array())
    {
        // line 12
        echo "    ";
        if (($context["isAjax"] ?? null)) {
            // line 13
            echo "        ";
            $context["showPlaces"] = array();
            // line 14
            echo "        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["barQuery"] ?? null), "all", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["place"]) {
                // line 15
                echo "            ";
                if ( !twig_test_empty(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["place"], "location", array()))) {
                    // line 16
                    echo "                ";
                    $context["showPlaces"] = twig_array_merge(($context["showPlaces"] ?? null), array(0 => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["place"], "location", array())));
                    // line 17
                    echo "            ";
                }
                // line 18
                echo "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['place'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 19
            echo "
        ";
            // line 20
            echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(($context["showPlaces"] ?? null));
            echo "
    ";
        } else {
            // line 22
            echo "        ";
            $this->loadTemplate("_partials/wysiwyg", "things-to-do/drink/index", 22)->display(array("content" => array("sectionHeading" => "Drink", "copy" => "")));
            // line 28
            echo "        
        ";
            // line 29
            $this->loadTemplate("things-to-do/listingFilter", "things-to-do/drink/index", 29)->display(array("type" => "things-to-do/drink", "areas" =>             // line 31
($context["areas"] ?? null)));
            // line 33
            echo "
        ";
            // line 34
            $this->loadTemplate("_partials/map", "things-to-do/drink/index", 34)->display(array("places" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 35
($context["barQuery"] ?? null), "all", array(), "method")));
            // line 37
            echo "    ";
        }
    }

    public function getTemplateName()
    {
        return "things-to-do/drink/index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 37,  91 => 35,  90 => 34,  87 => 33,  85 => 31,  84 => 29,  81 => 28,  78 => 22,  73 => 20,  70 => 19,  64 => 18,  61 => 17,  58 => 16,  55 => 15,  50 => 14,  47 => 13,  44 => 12,  41 => 11,  37 => 2,  35 => 10,  33 => 6,  32 => 5,  30 => 4,  28 => 1,  22 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "things-to-do/drink/index", "/home/abry/Sites/caitlinandabry-com/templates/things-to-do/drink/index.twig");
    }
}
