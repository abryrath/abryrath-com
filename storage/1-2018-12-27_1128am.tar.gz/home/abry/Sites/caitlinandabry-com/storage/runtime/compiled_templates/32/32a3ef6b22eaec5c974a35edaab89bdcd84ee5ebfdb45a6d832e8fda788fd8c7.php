<?php

/* 500 */
class __TwigTemplate_da8c92597b7b7eeb35ec88ea2be6562dea5b8437a5bd96b34268fb1accd89595 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/message", "500", 1);
        $this->blocks = array(
            'message' => array($this, 'block_message'),
            '__internal_4d032bb1e4c71cd693f0c24f5bffbf62aff546bce4adc4764f00c23fd28808f3' => array($this, 'block___internal_4d032bb1e4c71cd693f0c24f5bffbf62aff546bce4adc4764f00c23fd28808f3'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/message";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Internal Server Error", "app");
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_message($context, array $blocks = array())
    {
        // line 5
        echo "    <h2>";
        echo twig_escape_filter($this->env, ($context["title"] ?? null), "html", null, true);
        echo "</h2>

    ";
        // line 7
        if (($context["message"] ?? null)) {
            // line 8
            echo "        ";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->markdownFilter(            $this->renderBlock("__internal_4d032bb1e4c71cd693f0c24f5bffbf62aff546bce4adc4764f00c23fd28808f3", $context, $blocks)), "html", null, true);
            // line 9
            echo "    ";
        } else {
            // line 10
            echo "        <p>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("An error occurred while processing your request.", "app"), "html", null, true);
            echo "</p>
    ";
        }
    }

    // line 8
    public function block___internal_4d032bb1e4c71cd693f0c24f5bffbf62aff546bce4adc4764f00c23fd28808f3($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, ($context["message"] ?? null), "html", null, true);
    }

    public function getTemplateName()
    {
        return "500";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 8,  53 => 10,  50 => 9,  47 => 8,  45 => 7,  39 => 5,  36 => 4,  32 => 1,  30 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "500", "/home/abry/Sites/caitlinandabry-com/vendor/craftcms/cms/src/templates/500.html");
    }
}
